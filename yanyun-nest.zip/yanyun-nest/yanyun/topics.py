"""题材包：一个行业/题材的词表与规则。

同一套引擎，换个题材，要换的不是代码，是这四样：
  1. 机构名的后缀（海事局、航运公司、保险公司…）
  2. 动作类型（航行警告、禁航、改线、费率…）
  3. 哪些动作算"第三方反应"
  4. 事件时间窗（多久之内的算同一轮）

这正是原设计稿缺的一层：它把"金融新闻""国际事件"当成需要改代码的事，
其实只需要换一份词表。
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class Topic:
    name: str
    version: str = "0.1"
    name_suffixes: list[str] = field(default_factory=list)
    action_types: dict[str, list[str]] = field(default_factory=dict)
    reaction_types: list[str] = field(default_factory=list)
    chain_window_hours: int = 72
    note: str = ""

    def match_action(self, text: str) -> Optional[str]:
        """返回句子里命中的动作类型（取命中最多的那一类）。"""
        best, best_hits = None, 0
        for action, keywords in self.action_types.items():
            hits = sum(1 for kw in keywords if kw in text)
            if hits > best_hits:
                best, best_hits = action, hits
        return best

    def is_reaction(self, action: Optional[str]) -> bool:
        return action is not None and action in self.reaction_types


def load_topic(path: str | Path) -> Topic:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return Topic(
        name=str(data.get("name") or Path(path).stem),
        version=str(data.get("version", "0.1")),
        name_suffixes=[str(x) for x in data.get("name_suffixes", [])],
        action_types={
            str(k): [str(x) for x in v] for k, v in (data.get("action_types") or {}).items()
        },
        reaction_types=[str(x) for x in data.get("reaction_types", [])],
        chain_window_hours=int(data.get("chain_window_hours", 72)),
        note=str(data.get("note", "")),
    )
