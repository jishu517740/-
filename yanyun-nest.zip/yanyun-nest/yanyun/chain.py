"""纵向层：事件 → 推论链 → 隐藏事件候选。

这是原设计稿完全没有的一层，也是"窥探秘密"真正发生的地方：
横向告诉你"谁在改口径"，纵向才回答"他们为什么连成一串"。

三条硬规矩，全部可被代码检查：
  1. 接头只有两种：同一实体，且时间差在窗口内。禁止"同一主题"当接头。
  2. 链条强度 = 各环线索权重的**最小值**（木桶），不是平均。
  3. 隐藏事件只允许"准备度"与"重定价"两种形态，都是可核对的命题；
     意图类命题一律不生成——公开材料无法证伪它。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from .graph import EvidenceBase
from .textutil import registered_domain
from .topics import Topic

_TIER_ORDER = {"A": 0, "B": 1, "C": 2, "D": 3}


def _worse(a: str, b: str) -> str:
    """取更弱的权重等级（A 最好）。"""
    return a if _TIER_ORDER.get(a, 9) >= _TIER_ORDER.get(b, 9) else b


def _parse(ts: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(ts)
    except (TypeError, ValueError):
        return None


@dataclass
class EventNode:
    event_id: str
    entity: str
    action: str
    date: str
    clue_ids: list[str] = field(default_factory=list)
    tier: str = "C"
    is_reaction: bool = False


@dataclass
class Link:
    from_event: str
    to_event: str
    gap_hours: float
    reason: str


@dataclass
class Chain:
    chain_id: str
    entity: str
    action: str
    nodes: list[EventNode]
    links: list[Link]
    strength: str


@dataclass
class HiddenCandidate:
    statement: str
    kind: str            # 准备度 / 重定价
    chain_id: str
    strength: str
    support_clue_ids: list[str]
    gap: str


@dataclass
class ChainReport:
    topic: str
    events: list[EventNode]
    chains: list[Chain]
    candidates: list[HiddenCandidate]
    notes: list[str] = field(default_factory=list)


def build_events(base: EvidenceBase, topic: Topic) -> list[EventNode]:
    """把线索折叠成带动作类型与日期的事件。"""
    buckets: dict[tuple[str, str, str], EventNode] = {}
    for clue in base.clues:
        if not clue.timestamp:
            continue
        action = topic.match_action(clue.content or clue.excerpt)
        if not action:
            continue
        date = clue.timestamp[:10]
        tier = getattr(clue, "tier", None) or "C"
        for entity in clue.entities or ["（未识别主体）"]:
            key = (entity, action, date)
            node = buckets.get(key)
            if node is None:
                node = EventNode(
                    event_id=f"E{len(buckets) + 1:03d}",
                    entity=entity,
                    action=action,
                    date=date,
                    tier=tier,
                    is_reaction=topic.is_reaction(action),
                )
                buckets[key] = node
            else:
                node.tier = _worse(node.tier, tier)
            if clue.clue_id not in node.clue_ids:
                node.clue_ids.append(clue.clue_id)

    events = sorted(buckets.values(), key=lambda e: (e.entity, e.date))
    return events


def build_chains(events: list[EventNode], topic: Topic) -> list[Chain]:
    """同一实体 + 同一动作 + 时间窗内，才允许接链。"""
    window = timedelta(hours=topic.chain_window_hours)
    by_key: dict[tuple[str, str], list[EventNode]] = {}
    for event in events:
        by_key.setdefault((event.entity, event.action), []).append(event)

    chains: list[Chain] = []
    for (entity, action), nodes in by_key.items():
        nodes = sorted(nodes, key=lambda n: n.date)
        run: list[EventNode] = []
        for node in nodes:
            if not run:
                run = [node]
                continue
            prev = _parse(run[-1].date)
            cur = _parse(node.date)
            if prev and cur and cur - prev <= window:
                run.append(node)
            else:
                _flush(chains, entity, action, run)
                run = [node]
        _flush(chains, entity, action, run)
    return chains


def _flush(chains: list[Chain], entity: str, action: str, run: list[EventNode]) -> None:
    if len(run) < 2:
        return
    links = []
    strength = run[0].tier
    for prev, cur in zip(run, run[1:]):
        p, c = _parse(prev.date), _parse(cur.date)
        gap = round((c - p).total_seconds() / 3600, 1) if p and c else 0.0
        links.append(
            Link(
                from_event=prev.event_id,
                to_event=cur.event_id,
                gap_hours=gap,
                reason=f"同一实体「{entity}」· 同一动作「{action}」· 间隔 {gap} 小时",
            )
        )
        strength = _worse(strength, cur.tier)
    chains.append(
        Chain(
            chain_id=f"L{len(chains) + 1}",
            entity=entity,
            action=action,
            nodes=run,
            links=links,
            strength=strength,
        )
    )


def derive_hidden(base: EvidenceBase, topic: Topic, chains: list[Chain],
                  events: list[EventNode]) -> list[HiddenCandidate]:
    out: list[HiddenCandidate] = []
    for chain in chains:
        first, last = None, None
        for node in chain.nodes:
            dt = _parse(node.date)
            if dt is None:
                continue
            first = dt if first is None or dt < first else first
            last = dt if last is None or dt > last else last
        days = (last - first).days + 1 if first and last else 0
        support = [cid for node in chain.nodes for cid in node.clue_ids]

        out.append(
            HiddenCandidate(
                statement=(
                    f"{chain.entity} 的「{chain.action}」在 {days} 天内连续出现 "
                    f"{len(chain.nodes)} 次，节奏与覆盖范围都在推进，"
                    f"已构成可核对的常态化，而不是单次动作。"
                ),
                kind="准备度",
                chain_id=chain.chain_id,
                strength=chain.strength,
                support_clue_ids=support,
                gap="缺一份说明本次安排是否延续的官方口径；否则无法区分常态化与临时安排。",
            )
        )

        # 第三方反应：同一时间窗内、不同主体的经济类动作
        if first and last:
            reactions = [
                e for e in events
                if e.is_reaction
                and e.entity != chain.entity
                and _parse(e.date)
                and first - timedelta(hours=24) <= _parse(e.date) <= last + timedelta(hours=72)
            ]
            if reactions:
                names = "、".join(sorted({e.entity for e in reactions}))
                worst_reaction = max(
                    (e.tier for e in reactions), key=lambda t: _TIER_ORDER.get(t, 9)
                )
                out.append(
                    HiddenCandidate(
                        statement=(
                            f"该区域的商业运营已被按高风险重新定价："
                            f"{names} 在 {chain.entity} 动作的同一时间窗内改变了航线或费率，"
                            f"而这个判断没有等官方结论。"
                        ),
                        kind="重定价",
                        chain_id=chain.chain_id,
                        strength=_worse(chain.strength, worst_reaction),
                        support_clue_ids=support + [c for e in reactions for c in e.clue_ids],
                        gap="缺保险费率的连续序列；单次调整无法区分风险重估与季节性波动。",
                    )
                )
    return out


def build_chain_report(base: EvidenceBase, topic: Topic) -> ChainReport:
    events = build_events(base, topic)
    chains = build_chains(events, topic)
    candidates = derive_hidden(base, topic, chains, events)
    notes: list[str] = []
    if not events:
        notes.append(
            "没有抽到带动作类型与日期的事件：检查线索是否带 timestamp，"
            "或题材包的 action_types 是否覆盖了这批材料的说法。"
        )
    if events and not chains:
        notes.append(
            "事件之间存在断链：没有同一实体 + 同一动作落在时间窗内的连续动作，"
            "此时只能做横向结论，不要强行接链。"
        )
    return ChainReport(
        topic=topic.name, events=events, chains=chains, candidates=candidates, notes=notes
    )
