"""燕云推案：新闻线索调查与双阶段推论引擎。

    from yanyun import investigate, HeuristicBackend, load_articles

    articles = load_articles("samples/articles.json")
    result = investigate(articles, HeuristicBackend())
"""
from __future__ import annotations

from .backends.heuristic import HeuristicBackend
from .fetch import Article, load_articles, resolve_inputs
from .graph import EvidenceBase, build_evidence_base
from .pipeline import Investigation, investigate
from .report import render_json, render_markdown, write_outputs
from .schema import Clue, Hypothesis, Verdict

__version__ = "0.1.0"

__all__ = [
    "Article",
    "Clue",
    "EvidenceBase",
    "HeuristicBackend",
    "Hypothesis",
    "Investigation",
    "Verdict",
    "build_evidence_base",
    "investigate",
    "load_articles",
    "render_json",
    "render_markdown",
    "resolve_inputs",
    "write_outputs",
]
