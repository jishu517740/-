"""输出层：把一次调查渲染成可读的报告 + 可复核的 JSON。

报告刻意按"人怎么核查这件事"排序，而不是按代码的流水线顺序：
先给结论摘要（含配额是否达标），再给硬信号，再给逐条假设，
最后才是线索台账——因为"我凭什么信"比"你查到了什么"更重要。
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from .pipeline import Investigation

_CONF_BADGE = {
    "confirmed": "🟢 confirmed（多源独立 + 无矛盾）",
    "probable": "🟡 probable（有锚点，但单源或存在未解释矛盾）",
    "speculative": "🔵 speculative（弱路径 / 类比 / 配额未达标）",
    "rejected": "🔴 rejected（有反证）",
}

_CON_ICON = {
    "numeric": "数值不一致",
    "temporal": "时间线冲突",
    "negation": "否认 vs 记录",
    "duplicate": "转载链（伪多源）",
}


def _short(text: str, limit: int = 72) -> str:
    text = (text or "").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _evidence_lines(inv: Investigation, ids: list[str]) -> list[str]:
    by_id = inv.base.by_id()
    lines: list[str] = []
    for cid in ids:
        clue = by_id.get(cid)
        if clue is None:
            lines.append(f"  - `{cid}`（线索不存在，已剔除）")
            continue
        lines.append(
            f"  - `{cid}` **{clue.kind}** · {_short(clue.content, 80)}\n"
            f"    - 来源：{clue.source_domain or '?'} ｜ 独立性组：{clue.independence_group}\n"
            f"    - 原文：> {_short(clue.excerpt, 120)}"
        )
    return lines or ["  - （无）"]


def render_markdown(inv: Investigation, title: str = "燕云推案 · 推论报告") -> str:
    lines: list[str] = [f"# {title}", ""]
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    groups = inv.source_groups()

    lines.append(
        f"> 生成时间：{stamp}　｜　后端：`{inv.backend_name}`　｜　"
        f"材料：{len(inv.articles)} 篇　｜　线索：{len(inv.base.clues)} 条　｜　"
        f"假设：{len(inv.hypotheses)} 条　｜　独立信源组：{len(groups)}"
    )
    lines.append("")

    # ---------------- 证伪配额 ----------------
    lines.append("## 0. 证伪配额")
    lines.append("")
    mark = "✅" if inv.quota.met else "⚠️"
    lines.append(f"{mark} **{inv.quota.note}**")
    lines.append("")
    lines.append(
        "> 规则：至少有半数候选假设先被证伪，才允许输出结论。"
        "这一条是为了防止反过来——先有结论，再给每一条都配一段流畅的叙事。"
    )
    lines.append("")

    for warning in inv.warnings:
        lines.append(f"> ⚠️ {warning}")
    lines.append("")

    # ---------------- 摘要 ----------------
    lines.append("## 1. 结论摘要")
    lines.append("")
    if not inv.verdicts:
        lines.append("本轮没有产出任何裁定。")
    else:
        lines.append("| # | 假设 | 类型 | 裁定 | 独立性 | 证据缺口 |")
        lines.append("|---|---|---|---|---|---|")
        for i, v in enumerate(inv.verdicts, 1):
            lines.append(
                f"| {i} | {_short(v.hypothesis, 46)} | {v.type} | "
                f"**{v.revised_confidence}** | {v.source_independence} | "
                f"{_short(v.evidence_gap or '已被反证', 40)} |"
            )
    lines.append("")

    # ---------------- 硬信号 ----------------
    lines.append("## 2. 硬信号（代码预检，未经模型解释）")
    lines.append("")
    if not inv.base.contradictions:
        lines.append("未发现可机器判定的矛盾。注意：这只说明材料自洽，不说明材料为真。")
    else:
        buckets: dict[str, list] = {}
        for con in inv.base.contradictions:
            buckets.setdefault(con.kind, []).append(con)
        for kind, items in buckets.items():
            lines.append(f"### {_CON_ICON.get(kind, kind)}（{len(items)}）")
            lines.append("")
            for con in items:
                lines.append(
                    f"- `{con.clue_a}` ↔ `{con.clue_b}`：{con.detail}"
                )
            lines.append("")
    lines.append("")

    # ---------------- 逐条裁定 ----------------
    lines.append("## 3. 假设与裁定")
    lines.append("")
    if not inv.verdicts:
        lines.append("（无）")
    for i, v in enumerate(inv.verdicts, 1):
        lines.append(f"### 假设 {i}｜{_CONF_BADGE.get(v.revised_confidence, v.revised_confidence)}")
        lines.append("")
        lines.append(f"**陈述**：{v.hypothesis}")
        lines.append("")
        lines.append(f"- **类型**：`{v.type}`")
        lines.append(f"- **可证伪预测**：{v.falsifiable_prediction}")
        lines.append(f"- **证伪检验**：`{v.falsification_result}`")
        lines.append(f"- **来源独立性**：`{v.source_independence}`")
        lines.append(f"- **主张/事实混淆**：`{v.claim_fact_confusion}`")
        if v.overrides:
            lines.append(f"- **代码守门覆写**：`{', '.join(v.overrides)}`")
        lines.append("")
        lines.append("**支撑证据**：")
        lines.extend(_evidence_lines(inv, v.supporting_clue_ids))
        lines.append("")
        lines.append("**反证**：")
        if v.contradicting_clue_ids:
            lines.extend(_evidence_lines(inv, v.contradicting_clue_ids))
        else:
            lines.append("  - （未发现）")
        lines.append("")
        lines.append(f"**证据缺口**：{v.evidence_gap or '（已被反证，无需补充证据；被推翻的假设本身排除了一个解释）'}")
        lines.append("")
        lines.append(f"**裁定理据**：{v.one_line_reason}")
        lines.append("")

    # ---------------- 纵向链 ----------------
    if inv.chain is not None:
        lines.extend(_render_chain(inv))

    # ---------------- 信源盘点 ----------------
    lines.append("## 5. 信源独立性盘点")
    lines.append("")
    lines.append("> 同一组内的报道**不算**互相交叉验证，哪怕它们来自不同域名。")
    lines.append("")
    lines.append("| 独立性组 | 包含域名 | 线索数 |")
    lines.append("|---|---|---|")
    for group, domains in sorted(inv.source_groups().items()):
        uniq = sorted(set(domains))
        count = sum(1 for c in inv.base.clues if c.independence_group == group)
        lines.append(f"| {group} | {', '.join(uniq)} | {count} |")
    lines.append("")

    # ---------------- 线索台账 ----------------
    lines.append("## 6. 线索台账")
    lines.append("")
    lines.append("| clue_id | 类型 | 结构化陈述 | 时间 | 来源 | 组 |")
    lines.append("|---|---|---|---|---|---|")
    for c in inv.base.clues:
        lines.append(
            f"| `{c.clue_id}` | {c.kind} | {_short(c.content, 50)} | "
            f"{c.timestamp or '-'} | {c.source_domain or '?'} | "
            f"{c.independence_group or '-'} |"
        )
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append(
        "**读法**：`confirmed` 才值得当作事实引用；`probable` 只能当作值得继续追的线；"
        "`speculative` 是提问，不是答案；`rejected` 是有价值的负结果——它排除了一条解释。"
    )
    lines.append("")
    return "\n".join(lines)


def _render_chain(inv: Investigation) -> list[str]:
    chain = inv.chain
    lines: list[str] = ["## 4. 纵向链（事件 → 推论链 → 隐藏事件）", ""]
    if chain is None:
        return lines
    lines.append(
        f"> 题材包：`{chain.topic}`　｜　事件：{len(chain.events)} 个　｜　"
        f"链：{len(chain.chains)} 条　｜　隐藏事件候选：{len(chain.candidates)} 条"
    )
    lines.append("")
    lines.append(
        "> 接头只有一种：**同一实体 + 同一动作 + 时间窗内**。"
        "“都在说同一件事”不算接头——那是氛围，不是链。"
    )
    lines.append("")
    for note in chain.notes:
        lines.append(f"> ⚠️ {note}")
    if chain.notes:
        lines.append("")

    if chain.events:
        lines.append("### 事件序列")
        lines.append("")
        lines.append("| 事件 | 主体 | 动作 | 日期 | 权重 |")
        lines.append("|---|---|---|---|---|")
        for event in chain.events:
            lines.append(
                f"| {event.event_id} | {event.entity} | {event.action} | "
                f"{event.date} | {event.tier} |"
            )
        lines.append("")

    if chain.chains:
        lines.append("### 链")
        lines.append("")
        for item in chain.chains:
            lines.append(f"**{item.chain_id} · {item.entity} · {item.action}**（强度 {item.strength}）")
            lines.append("")
            for link in item.links:
                lines.append(f"- {link.from_event} → {link.to_event}：{link.reason}")
            lines.append("")

    if chain.candidates:
        lines.append("### 隐藏事件候选")
        lines.append("")
        for cand in chain.candidates:
            lines.append(f"- **[{cand.kind} · 强度 {cand.strength}]** {cand.statement}")
            lines.append(f"  - 支撑线索：{', '.join(f'`{c}`' for c in cand.support_clue_ids)}")
            lines.append(f"  - 证据缺口：{cand.gap}")
        lines.append("")
        lines.append(
            "> 只生成**准备度**与**重定价**两类命题，它们都能被一份材料推翻。"
            "意图类命题（“某方计划…”）一律不生成：公开材料无法证伪它。"
        )
        lines.append("")
    return lines


def render_json(inv: Investigation) -> dict:
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "backend": inv.backend_name,
        "articles": [
            {"url": a.url, "title": a.title, "domain": a.source_domain, "chars": len(a.text)}
            for a in inv.articles
        ],
        "clues": [c.to_dict() for c in inv.base.clues],
        "contradictions": [con.to_dict() for con in inv.base.contradictions],
        "hypotheses": [h.to_dict() for h in inv.hypotheses],
        "verdicts": [v.to_dict() for v in inv.verdicts],
        "quota": inv.quota.to_dict(),
        "chain": None if inv.chain is None else {
            "topic": inv.chain.topic,
            "events": [e.__dict__ for e in inv.chain.events],
            "chains": [
                {
                    "chain_id": c.chain_id,
                    "entity": c.entity,
                    "action": c.action,
                    "strength": c.strength,
                    "nodes": [n.event_id for n in c.nodes],
                    "links": [l.__dict__ for l in c.links],
                }
                for c in inv.chain.chains
            ],
            "candidates": [c.__dict__ for c in inv.chain.candidates],
            "notes": inv.chain.notes,
        },
        "warnings": inv.warnings,
    }


def write_outputs(inv: Investigation, out_dir: str | Path,
                  title: str = "燕云推案 · 推论报告") -> tuple[Path, Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    # 同一秒内跑两次会撞名，后一次会静默覆盖前一次的报告
    stem = f"report-{stamp}"
    index = 1
    while (out / f"{stem}.md").exists() or (out / f"{stem}.json").exists():
        index += 1
        stem = f"report-{stamp}-{index}"
    md_path = out / f"{stem}.md"
    json_path = out / f"{stem}.json"
    md_path.write_text(render_markdown(inv, title=title), encoding="utf-8")
    json_path.write_text(
        json.dumps(render_json(inv), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return md_path, json_path
