"""数据结构：线索 / 假设 / 裁定。

对应《燕云推案》设计文档的"证据台—推理引擎—推论面板"三层：
    Clue      = 拆解出来的线索（带原文锚点）
    Hypothesis= 大胆阶段的候选假设（必须带可证伪预测）
    Verdict   = 小心阶段的裁定（四级置信 + 证据缺口）
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

# 线索类型：事实 / 主张 / 事件 / 时间标记
CLUE_KINDS = ("fact", "claim", "event", "timestamp")

# 假设的四种受控发散算子
HYPOTHESIS_TYPES = ("bridge", "counterfactual", "motive", "analogy")

# 四级置信裁定
CONFIDENCE_LEVELS = ("confirmed", "probable", "speculative", "rejected")
_CONFIDENCE_ORDER = {name: i for i, name in enumerate(CONFIDENCE_LEVELS)}

# 裁判的中间结论
VERDICTS = ("supported", "weakly_supported", "contradicted", "underdetermined")
_VERDICT_CEILING = {
    "supported": "confirmed",
    "weakly_supported": "probable",
    "contradicted": "rejected",
    "underdetermined": "speculative",
}

# 来源独立性
INDEPENDENCE = ("single", "multiple_independent", "unknown")


def stable_id(seed: str, index: int = 0) -> str:
    """确定性 id：同一输入在任何机器、任何 PYTHONHASHSEED 下都相同。

    原稿用的是 ``hash(url) % 10000``，会随进程随机化而漂移，
    导致同一份材料两次运行得到不同 clue_id，报告无法比对。
    """
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8]
    return f"{digest}-{index}"


@dataclass
class Clue:
    """一条被拆解出来的线索，绑定来源锚点。"""

    clue_id: str
    source_url: str
    source_title: str
    excerpt: str          # 原文锚点，必须逐字保留
    kind: str             # fact / claim / event / timestamp
    entities: list[str] = field(default_factory=list)
    content: str = ""
    timestamp: Optional[str] = None
    source_domain: Optional[str] = None
    independence_group: Optional[str] = None  # 同通讯社/同转引链归组
    sentence_index: Optional[int] = None
    # 线索权重等级：A 硬（公告/记录）/ B 实（多源独立）/ C 软（单源）/ D 悬（匿名）
    tier: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Hypothesis:
    """大胆阶段的产物：可发散，但必须自带可证伪预测。"""

    hypothesis: str
    type: str
    trigger_clue_ids: list[str]
    falsifiable_prediction: str
    confidence_prior: str = "medium"   # 仅表示"值得优先验证的程度"
    analogy_source: Optional[str] = None
    # 可执行的检验探针：规则后端用它把"应该观察到什么"落到具体检查上。
    # LLM 后端不填，裁判阶段会退回语言判断。
    probe: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Verdict:
    """小心阶段的产物：一条假设的完整裁定。"""

    hypothesis: str
    type: str
    falsifiable_prediction: str
    verdict: str                        # supported / weakly_supported / contradicted / underdetermined
    revised_confidence: str             # confirmed / probable / speculative / rejected
    supporting_clue_ids: list[str] = field(default_factory=list)
    contradicting_clue_ids: list[str] = field(default_factory=list)
    source_independence: str = "unknown"
    claim_fact_confusion: bool = False
    falsification_result: str = "untestable"  # falsified / testable_but_unresolved / untestable
    evidence_gap: str = ""
    one_line_reason: str = ""
    # 审计信息：哪些字段由代码守门改写过，而不是模型给的
    overrides: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def verdict_to_confidence(verdict: str) -> str:
    """中间结论 → 置信上限。模型/规则只能往下压，不能往上抬。"""
    return _VERDICT_CEILING.get(verdict, "speculative")


def confidence_rank(level: str) -> int:
    """0 最高（confirmed），数字越大越不可信。"""
    return _CONFIDENCE_ORDER.get(level, 9)


def clamp_confidence(level: str, ceiling: str) -> str:
    """把 level 压到不高于 ceiling（conf 越不可信 rank 越大）。"""
    return level if confidence_rank(level) >= confidence_rank(ceiling) else ceiling
