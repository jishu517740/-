"""三种后端：LLM（语言理解）/ 启发式（离线兜底与对照组）。"""
from __future__ import annotations

from .base import Backend
from .heuristic import HeuristicBackend

__all__ = ["Backend", "HeuristicBackend"]
