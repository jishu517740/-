"""后端接口：三个阶段的同一道缝。

之所以把它抽成 protocol，是因为"大胆"和"小心"必须能换成不同的实现来验收：
    LLMBackend       —— 真模型，负责发散与语言理解
    HeuristicBackend —— 确定性规则，负责在没有任何 key 的情况下跑通全流程
                        同时也是 LLM 的对照组：两边结论不一致时，先怀疑模型。

三个方法对应文档里的三阶段：拆线索 / 出假设 / 做裁定。
"""
from __future__ import annotations

from typing import Protocol, Optional

from ..graph import EvidenceBase
from ..schema import Clue, Hypothesis, Verdict


class Backend(Protocol):
    name: str

    def extract_clues(self, article_text: str, url: str, title: str,
                      default_year: Optional[int] = None) -> list[Clue]:
        """阶段一：从单篇文章拆出线索（excerpt 必须逐字回指原文）。"""
        ...

    def generate_hypotheses(self, base: EvidenceBase, max_h: int = 5,
                            focus_entities: Optional[list[str]] = None) -> list[Hypothesis]:
        """阶段二：大胆发散，每条假设必须带可证伪预测。"""
        ...

    def adjudicate(self, hypothesis: Hypothesis, base: EvidenceBase,
                   pool_text: str) -> Verdict:
        """阶段三：只依据证据池做裁定。"""
        ...
