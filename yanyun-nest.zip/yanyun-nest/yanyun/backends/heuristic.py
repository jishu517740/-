"""离线确定性后端：不调用任何模型，也能把三阶段跑完。

它同时是两个东西：
  1. 无 key 时的可用实现（先把纪律跑通，再谈模型）；
  2. 有 key 时的对照组——如果 LLM 的裁定与这套规则冲突，
     冲突本身就是最有价值的信号，值得人工看一眼。

它只做代码能算的事：锚点、数值、日期、转载链、来源独立性。
它的假设是模板化的，但每条都绑定一个**可执行的检验探针**（probe）：
假设说"数值应该一致"，代码就真的去材料里逐个比；不一致就当场推翻。
宁可笨，不要虚——一条能被自己的证据推翻的假设，比十条漂亮叙事有用。
"""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date
from typing import Optional

from ..graph import EvidenceBase, instance_key
from ..schema import Clue, Hypothesis, Verdict, clamp_confidence, stable_id, verdict_to_confidence
from ..textutil import find_iso_dates, find_quantities, normalize_ws, shingles, overlap, split_sentences

# ----------------------------------------------------------------------
# 阶段一：启发式拆线索
# ----------------------------------------------------------------------

_NAME_SUFFIXES = (
    "公司", "集团", "控股", "科技", "物流", "银行", "证券", "研究院",
    "管理局", "监管局", "委员会", "大学", "医院", "能源", "地产",
    "矿业", "智能仓", "事业部", "工作室",
)
_STOP_CHARS = set("由在的和与向对为称表示是等及、，。：；（）「」《》“”‘’ 　")

_CLAIM_WORDS = ("称", "表示", "宣布", "否认", "回应", "指出", "认为", "预计",
                "声称", "强调", "透露", "据", "将会", "承诺")
_EVENT_WORDS = ("发生", "举行", "启动", "签署", "开工", "投产", "竣工",
                "交付", "上线", "发布", "事故", "爆", "起火", "处罚", "备案",
                "暂停", "绕飞", "改线", "上调", "下调", "扩大")

_POSITIVE_FACT = re.compile(r"受伤|伤亡|死亡|事故|违规|罚款|停产|起火|泄漏|超支|延期")
_NEGATION = re.compile(r"无人(?:受伤|伤亡)|未(?:发生|造成)|没有(?:人员)?(?:受伤|伤亡)|否认|不存在|并非")

_LATIN = re.compile(r"\b[A-Z][A-Za-z0-9\-]{1,9}\b")
_QUOTED = re.compile(r"[《「]([^》」]{2,20})[》」]")
_PERSON = re.compile(r"([\u4e00-\u9fa5])某")

# 实体名左边遇到这些词就必须断开，否则会把动词吃进机构名
_BOUNDARY_WORDS = (
    "推进", "提供", "包括", "涉及", "显示", "表示", "回应", "指出", "认为",
    "签署", "公布", "记录", "计划", "实现", "完成", "举行", "发生", "启动",
    "共同", "项目", "协议", "文件", "信息", "期间", "方面", "当地", "该",
    "将", "已", "曾", "并", "就", "在", "于", "为", "由", "与", "和", "对",
    "向", "及", "的", "称", "据",
)

# 只有这些量纲才值得做"数值一致性"检验（百分比和人数含义不同，不混）
_SCALE_UNITS = {"亿元", "万元", "元", "吨", "公里", "万台", "人次", "架次", "艘次"}


def _walk_left(text: str, end: int, limit: int = 6,
               blocked: set[int] | None = None) -> str:
    """从 end 往左取一段连续汉字，遇到虚词/标点/动词/另一个名字的结尾就停。"""
    blocked = blocked or set()
    start = end
    while start > 0 and end - start < limit and start not in blocked:
        if text[start - 1] in _STOP_CHARS:
            break
        if any(text[:start].endswith(word) for word in _BOUNDARY_WORDS):
            break
        start -= 1
    return text[start:end]


def guess_entities(sentence: str, extra_suffixes: tuple[str, ...] = ()) -> list[str]:
    """不用 NER 模型也能拿到八成实体：机构后缀、书名号、姓氏+某、大写词。

    多个后缀可能落在同一个名字里（"星港物流华南智能仓"里同时有"物流"和
    "智能仓"），所以先收集所有后缀位置，再让每个后缀只向左吃到上一个
    后缀的结尾为止——否则会把两个机构粘成一个。
    """
    found: list[str] = []
    suffixes = tuple(_NAME_SUFFIXES) + tuple(extra_suffixes)

    matches: list[tuple[int, int, str]] = []
    for suffix in suffixes:
        for m in re.finditer(re.escape(suffix), sentence):
            matches.append((m.start(), m.end(), suffix))
    matches.sort()
    suffix_ends = {end for _start, end, _suffix in matches}

    for start, _end, suffix in matches:
        head = _walk_left(sentence, start, blocked=suffix_ends)
        if len(head) >= 2:
            found.append(head + suffix)

    for m in _QUOTED.finditer(sentence):
        found.append(m.group(1))

    for m in _PERSON.finditer(sentence):
        found.append(m.group(0))

    for m in _LATIN.finditer(sentence):
        token = m.group(0)
        if token.isupper() or any(ch.isdigit() for ch in token):
            found.append(token)

    # 长的优先：避免"星港物流"和"星港物流公司"同时成为两个实体
    ordered = sorted(set(found), key=len, reverse=True)
    kept: list[str] = []
    for name in ordered:
        name = name.strip()
        if not (2 <= len(name) <= 12):
            continue
        if any(name in other for other in kept):
            continue
        kept.append(name)
    return kept


def _quantities(clue: Clue) -> list[tuple[float, str]]:
    # content 与 excerpt 是同一句时必须去重，否则每个数字会被数两次
    content, excerpt = clue.content or "", clue.excerpt or ""
    text = content if content == excerpt else f"{content} {excerpt}"
    return find_quantities(text)


_SPEAK_VERBS = ("报道", "表示", "称", "指出", "认为", "透露", "宣称", "声明")


def _speaker_of(clue: Clue, base: EvidenceBase) -> Optional[str]:
    """谁在说话：取动作词之前、最靠近动作词的那个实体。

    "东方通讯社称，东区海事局记录到…" → 说话人是东方通讯社，不是海事局。
    """
    text = clue.content or clue.excerpt
    cut = len(text)
    for verb in _SPEAK_VERBS:
        pos = text.find(verb)
        if 0 <= pos < cut:
            cut = pos
    prefix = text[:cut]
    best, best_pos = None, -1
    for entity in clue.entities:
        pos = prefix.rfind(entity)
        if pos > best_pos:
            best, best_pos = entity, pos
    return best


class HeuristicBackend:
    name = "heuristic"

    def __init__(self, extra_suffixes: tuple[str, ...] = ()) -> None:
        # 题材包可以补充机构后缀（海事局、航运公司…），不用改代码
        self.extra_suffixes = tuple(extra_suffixes)

    # ------------------------------------------------------------------
    # 阶段一
    # ------------------------------------------------------------------

    def extract_clues(self, article_text: str, url: str, title: str,
                      default_year: Optional[int] = None) -> list[Clue]:
        clues: list[Clue] = []
        for idx, sentence in enumerate(split_sentences(article_text)):
            dates = find_iso_dates(sentence, default_year)
            clues.append(
                Clue(
                    clue_id=stable_id(f"{url}|{normalize_ws(sentence)}", idx),
                    source_url=url,
                    source_title=title,
                    excerpt=sentence,
                    kind=self._classify(sentence),
                    entities=guess_entities(sentence, self.extra_suffixes),
                    content=sentence[:160],
                    timestamp=dates[0] if dates else None,
                    sentence_index=idx,
                )
            )
        return clues

    @staticmethod
    def _classify(sentence: str) -> str:
        if any(word in sentence for word in _CLAIM_WORDS):
            return "claim"
        if any(word in sentence for word in _EVENT_WORDS):
            return "event"
        if len(sentence) < 30 and find_iso_dates(sentence):
            return "timestamp"
        return "fact"

    # ------------------------------------------------------------------
    # 阶段二：每条假设都带一个可执行探针
    # ------------------------------------------------------------------

    def generate_hypotheses(self, base: EvidenceBase, max_h: int = 5,
                            focus_entities: Optional[list[str]] = None) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        out.extend(self._value_hypotheses(base))
        out.extend(self._date_hypotheses(base))
        out.extend(self._negation_hypotheses(base))
        out.extend(self._bridge_hypotheses(base))
        out.extend(self._underreport_hypotheses(base))

        if focus_entities:
            focus = set(focus_entities)
            out = [
                h for h in out
                if focus & {
                    e for cid in h.trigger_clue_ids
                    for e in (base.clue(cid).entities if base.clue(cid) else [])
                }
            ]
        seen, unique = set(), []
        for h in out:
            key = (h.type, h.hypothesis)
            if key in seen:
                continue
            seen.add(key)
            unique.append(h)
        return unique[:max_h]

    def _value_hypotheses(self, base: EvidenceBase) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        done: set[tuple[str, str, str]] = set()
        for con in base.contradictions:
            if con.kind != "numeric" or not con.entity:
                continue
            unit = con.unit or self._unit_from(base, con.entity)
            instance = con.instance or "unknown"
            if unit not in _SCALE_UNITS or (con.entity, unit, instance) in done:
                continue
            done.add((con.entity, unit, instance))
            # 只在"同一个实例"里比数值：不同编号是不同次发布，不是矛盾
            values = sorted({
                v for c in self._clues_on(base, con.entity)
                if instance_key(c) == instance
                for v, u in _quantities(c) if u == unit
            })
            if len(values) < 2:
                continue
            low = values[0]
            out.append(
                Hypothesis(
                    hypothesis=(
                        f"{con.entity} 公布的最小数值 {low:g}{unit} 是真实值，"
                        f"其余 {len(values) - 1} 个更大的数值来自统计口径差异。"
                    ),
                    type="counterfactual",
                    trigger_clue_ids=[con.clue_a, con.clue_b],
                    falsifiable_prediction=(
                        f"若 {low:g}{unit} 为真实值，则 {con.entity} 在各独立材料中的"
                        f"同一口径数值都应落在 {low:g}{unit} 的 ±10% 内。"
                    ),
                    confidence_prior="high",
                    probe={
                        "kind": "value_agreement",
                        "entity": con.entity,
                        "value": low,
                        "unit": unit,
                        "tol": 0.10,
                    },
                )
            )
        return out

    def _date_hypotheses(self, base: EvidenceBase) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        for con in base.contradictions:
            if con.kind != "temporal" or not con.entity or not con.action:
                continue
            out.append(
                Hypothesis(
                    hypothesis=(
                        f"{con.entity} 的「{con.action}」只有一个真实日期，"
                        f"两份材料的差异来自其中一方记错或口径不同。"
                    ),
                    type="counterfactual",
                    trigger_clue_ids=[con.clue_a, con.clue_b],
                    falsifiable_prediction=(
                        f"若两份记录指向同一动作，则 {con.entity} 的「{con.action}」日期"
                        f"在各材料中应相差不超过 30 天。"
                    ),
                    confidence_prior="medium",
                    probe={
                        "kind": "date_agreement",
                        "entity": con.entity,
                        "action": con.action,
                        "tol_days": 30,
                    },
                )
            )
        return out

    def _negation_hypotheses(self, base: EvidenceBase) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        seen: set[str] = set()
        for con in base.contradictions:
            if con.kind != "negation" or not con.entity or con.entity in seen:
                continue
            seen.add(con.entity)
            out.append(
                Hypothesis(
                    hypothesis=f"{con.entity} 一方的否认成立，与之相反的记录属于误传。",
                    type="motive",
                    trigger_clue_ids=[con.clue_a, con.clue_b],
                    falsifiable_prediction=(
                        f"若否认成立，各独立材料中不应再出现与否认相反的事实记录"
                        f"（事故、伤亡、处罚、停产等）。"
                    ),
                    confidence_prior="high",
                    probe={"kind": "negation_record", "entity": con.entity},
                )
            )
        return out

    def _bridge_hypotheses(self, base: EvidenceBase) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        index = base.entity_index
        entities = [e for e, ids in index.items() if 2 <= len(ids) <= 12 and not e.endswith("某")]
        for i, a in enumerate(entities):
            for b in entities[i + 1 :]:
                shared = sorted(set(index[a]) & set(index[b]))
                # 同一句话的两份转载不能算两条证据
                seen_text: set[str] = set()
                unique: list[str] = []
                for cid in shared:
                    clue = base.clue(cid)
                    if clue is None:
                        continue
                    key = normalize_ws(clue.excerpt)
                    if key in seen_text:
                        continue
                    seen_text.add(key)
                    unique.append(cid)
                if len(unique) < 2:
                    continue
                out.append(
                    Hypothesis(
                        hypothesis=(
                            f"{a} 与 {b} 之间的关系，可能不止公开报道写的那一层。"
                        ),
                        type="bridge",
                        trigger_clue_ids=unique[:3],
                        falsifiable_prediction=(
                            f"应在合同、任命、采购或登记记录中同时看到 {a} 与 {b}；"
                            f"找不到的话，这条只能停在猜测。"
                        ),
                        confidence_prior="medium",
                        probe={
                            "kind": "documents_for_pair",
                            "entities": [a, b],
                            "keywords": ["股东", "持股", "股权", "担保", "增资",
                                         "采购", "中标", "合同", "任命", "登记"],
                        },
                    )
                )
                if len(out) >= 2:
                    return out
        return out

    def _underreport_hypotheses(self, base: EvidenceBase) -> list[Hypothesis]:
        out: list[Hypothesis] = []
        seen: set[str] = set()
        for con in base.contradictions:
            if con.kind != "numeric" or not con.entity or con.entity in seen:
                continue
            unit = con.unit or self._unit_from(base, con.entity)
            if unit not in _SCALE_UNITS:
                continue
            claim_vals = [
                v for c in self._clues_on(base, con.entity)
                if c.kind == "claim"
                for v, u in _quantities(c) if u == unit
            ]
            if not claim_vals:
                continue
            fact_vals = [
                v for c in self._clues_on(base, con.entity)
                if c.kind in ("fact", "event")
                for v, u in _quantities(c) if u == unit
            ]
            seen.add(con.entity)
            low = min(claim_vals)
            # 方向决定罪名：低于独立记录 = 压低；高于 = 夸大
            direction = "over" if fact_vals and low > max(fact_vals) else "under"
            # 表述主体 ≠ 被提及主体：谁说的话，不能记在被说的机构头上
            speaker = None
            for c in self._clues_on(base, con.entity):
                if c.kind != "claim":
                    continue
                if not any(u == unit for _v, u in _quantities(c)):
                    continue
                speaker = _speaker_of(c, base)
                if speaker:
                    break
            actor = speaker if speaker and speaker != con.entity else con.entity
            if direction == "over":
                if speaker and speaker != con.entity:
                    hypothesis_text = (
                        f"{speaker} 对 {con.entity} 的对外表述高于后者自己的记录，"
                        f"存在夸大。"
                    )
                else:
                    hypothesis_text = (
                        f"{con.entity} 的对外表述高于独立记录，存在夸大而不是披露义务。"
                    )
                prediction = (
                    f"若存在夸大，则 {actor} 给出的数值应高于 {con.entity} 独立材料中的数值，"
                    f"且至少两个彼此独立的来源给出更低的同一口径数值。"
                )
            else:
                hypothesis_text = (
                    f"{con.entity} 的对外口径系统性低于独立记录，"
                    f"存在压低规模的动机而不是披露义务。"
                )
                prediction = (
                    f"若存在压低，则 {con.entity} 的对外数值应低于独立材料中的数值，"
                    f"且至少两个彼此独立的来源给出更高的同一口径数值。"
                )
            out.append(
                Hypothesis(
                    hypothesis=hypothesis_text,
                    type="motive",
                    trigger_clue_ids=[con.clue_a, con.clue_b],
                    falsifiable_prediction=prediction,
                    confidence_prior="high",
                    probe={
                        "kind": "underreport",
                        "entity": con.entity,
                        "unit": unit,
                        "claim_value": low,
                        "direction": direction,
                        "instance": con.instance or "unknown",
                    },
                )
            )
        return out

    # ------------------------------------------------------------------
    # 阶段三：跑探针 → 裁定
    # ------------------------------------------------------------------

    def adjudicate(self, hypothesis: Hypothesis, base: EvidenceBase,
                   pool_text: str) -> Verdict:
        triggers = [c for c in (base.clue(i) for i in hypothesis.trigger_clue_ids) if c]
        probe = hypothesis.probe or {}

        if probe.get("kind"):
            result = self._run_probe(probe, base)
        else:  # 没有探针（例如来自 LLM 的假设）：退回保守判断
            result = self._fallback(hypothesis, base, triggers)

        contradicting = result["contradicting"]
        supporting = result["supporting"]
        falsification = result["falsification"]

        if falsification == "falsified":
            verdict = "contradicted"
        elif falsification == "untestable":
            verdict = "underdetermined"
        elif result.get("supported"):
            verdict = "supported"
        elif supporting:
            verdict = "weakly_supported"
        else:
            verdict = "underdetermined"

        claim_fact_confusion = bool(triggers) and all(c.kind == "claim" for c in triggers)

        groups = {
            base.clue(cid).independence_group
            for cid in supporting
            if base.clue(cid) and base.clue(cid).independence_group
        }
        if not supporting:
            independence = "unknown"
        elif len(groups) >= 2:
            independence = "multiple_independent"
        else:
            independence = "single"

        confidence = verdict_to_confidence(verdict)
        if claim_fact_confusion or independence == "single":
            confidence = clamp_confidence(confidence, "probable")
        if falsification == "untestable":
            confidence = clamp_confidence(confidence, "speculative")
        # 动机类结论再强也只能到 probable：动机永远不是纸面材料能"证实"的东西
        if result.get("max_confidence"):
            confidence = clamp_confidence(confidence, result["max_confidence"])

        return Verdict(
            hypothesis=hypothesis.hypothesis,
            type=hypothesis.type,
            falsifiable_prediction=hypothesis.falsifiable_prediction,
            verdict=verdict,
            revised_confidence=confidence,
            supporting_clue_ids=supporting,
            contradicting_clue_ids=sorted(contradicting),
            source_independence=independence,
            claim_fact_confusion=claim_fact_confusion,
            falsification_result=falsification,
            evidence_gap=result["gap"],
            one_line_reason=result["reason"],
        )

    # ------------------------------------------------------------------
    def _run_probe(self, probe: dict, base: EvidenceBase) -> dict:
        kind = probe["kind"]
        if kind == "value_agreement":
            return self._probe_value(probe, base)
        if kind == "date_agreement":
            return self._probe_date(probe, base)
        if kind == "negation_record":
            return self._probe_negation(probe, base)
        if kind == "documents_for_pair":
            return self._probe_documents(probe, base)
        if kind == "underreport":
            return self._probe_underreport(probe, base)
        return self._no_probe()

    @staticmethod
    def _no_probe() -> dict:
        return {
            "falsification": "untestable",
            "contradicting": set(),
            "supporting": [],
            "gap": "该假设没有绑定可执行的检验条件，只能算叙事性猜测。",
            "reason": "找不到能检验该预测的线索。",
        }

    def _probe_value(self, probe: dict, base: EvidenceBase) -> dict:
        entity, value, unit, tol = probe["entity"], probe["value"], probe["unit"], probe["tol"]
        records = [
            c for c in self._clues_on(base, entity)
            if c.kind in ("fact", "event")
            for v, u in _quantities(c) if u == unit
        ]
        if not records:
            return {
                "falsification": "untestable",
                "contradicting": set(),
                "supporting": [],
                "gap": f"没有找到 {entity} 在 {unit} 口径上的独立记录。",
                "reason": "证据池中没有可比的独立数值。",
            }
        offenders, agree = [], []
        for c in records:
            for v, u in _quantities(c):
                if u != unit:
                    continue
                if abs(v - value) > abs(value) * tol:
                    offenders.append(c.clue_id)
                else:
                    agree.append(c.clue_id)
        if offenders:
            spread = sorted({v for c in records for v, u in _quantities(c) if u == unit})
            return {
                "falsification": "falsified",
                "contradicting": set(offenders),
                "supporting": [],
                "gap": "",
                "reason": (
                    f"独立记录给出 {', '.join(f'{v:g}{unit}' for v in spread)}，"
                    f"与假设的 {value:g}{unit} 相差超过 {tol:.0%}，预测被直接否定。"
                ),
            }
        return {
            "falsification": "testable_but_unresolved",
            "contradicting": set(),
            "supporting": sorted(set(agree)),
            "gap": "所有独立记录都与该数值一致，但没有第二类材料交叉印证。",
            "reason": "现有独立记录未与该数值冲突。",
        }

    def _probe_date(self, probe: dict, base: EvidenceBase) -> dict:
        entity, action, tol = probe["entity"], probe["action"], probe["tol_days"]
        dated = [
            c for c in self._clues_on(base, entity)
            if c.timestamp and action in (c.content or c.excerpt)
        ]
        if len({c.timestamp for c in dated}) <= 1:
            return {
                "falsification": "testable_but_unresolved",
                "contradicting": set(),
                "supporting": [c.clue_id for c in dated],
                "gap": f"{entity} 的「{action}」目前只有一个日期，缺第二个独立记录。",
                "reason": "各材料日期一致，但没有第二份独立材料。",
            }
        ordered = sorted(dated, key=lambda c: c.timestamp or "")
        first, last = ordered[0], ordered[-1]
        try:
            gap_days = (
                date.fromisoformat(last.timestamp) - date.fromisoformat(first.timestamp)
            ).days
        except (TypeError, ValueError):
            gap_days = tol + 1
        if gap_days > tol:
            return {
                "falsification": "falsified",
                "contradicting": {first.clue_id, last.clue_id},
                "supporting": [],
                "gap": "",
                "reason": (
                    f"同一动作「{action}」被记为 {first.timestamp} 与 {last.timestamp}，"
                    f"相差 {gap_days} 天，超过 {tol} 天容差。"
                ),
            }
        return {
            "falsification": "testable_but_unresolved",
            "contradicting": set(),
            "supporting": [c.clue_id for c in dated],
            "gap": "日期差异在容差内，需要更多材料确认。",
            "reason": "两处日期在容差内。",
        }

    def _probe_negation(self, probe: dict, base: EvidenceBase) -> dict:
        entity = probe["entity"]
        records = [
            c for c in self._clues_on(base, entity)
            if c.kind in ("fact", "event")
            and _POSITIVE_FACT.search(c.content or c.excerpt)
            and not _NEGATION.search(c.content or c.excerpt)
        ]
        if records:
            return {
                "falsification": "falsified",
                "contradicting": {c.clue_id for c in records},
                "supporting": [],
                "gap": "",
                "reason": (
                    f"材料中存在 {len(records)} 条与否认相反的事实记录，"
                    f"否认与记录不能同时为真。"
                ),
            }
        return {
            "falsification": "untestable",
            "contradicting": set(),
            "supporting": [],
            "gap": "没有第三方记录（执法、医疗、保险）来验证这次否认。",
            "reason": "否认既没有被证实，也没有被证伪。",
        }

    def _probe_documents(self, probe: dict, base: EvidenceBase) -> dict:
        a, b = probe["entities"]
        keywords = probe["keywords"]
        both = [c for c in base.clues if a in c.excerpt and b in c.excerpt]
        hits = [c for c in both if any(k in c.excerpt for k in keywords)]
        if hits:
            return {
                "falsification": "testable_but_unresolved",
                "contradicting": set(),
                "supporting": [c.clue_id for c in hits],
                "gap": "关系已有公开文件，但资金流向仍不透明。",
                "reason": "两者的关系已有公开文件记载。",
            }
        return {
            "falsification": "untestable",
            "contradicting": set(),
            "supporting": [],
            "gap": (
                f"缺同时出现 {a} 与 {b} 的股东名单、担保记录或采购公告，"
                f"这类材料通常不在新闻里。"
            ),
            "reason": "现有材料无法触及这条预测。",
        }

    def _probe_underreport(self, probe: dict, base: EvidenceBase) -> dict:
        entity, unit, claim_value = probe["entity"], probe["unit"], probe["claim_value"]
        direction = probe.get("direction", "under")
        instance = probe.get("instance", "unknown")
        deviate: list[Clue] = []
        all_facts: list[Clue] = []
        for c in self._clues_on(base, entity):
            if c.kind not in ("fact", "event"):
                continue
            if instance != "unknown" and instance_key(c) != instance:
                continue
            for v, u in _quantities(c):
                if u != unit:
                    continue
                all_facts.append(c)
                if direction == "over":
                    if v < claim_value:
                        deviate.append(c)
                elif v > claim_value:
                    deviate.append(c)
        groups = {c.independence_group for c in deviate if c.independence_group}
        if len(groups) >= 2:
            word = "高报" if direction == "over" else "低报"
            return {
                "falsification": "testable_but_unresolved",
                "contradicting": set(),
                "supporting": [c.clue_id for c in deviate],
                "supported": True,
                "max_confidence": "probable",
                "gap": f"对外口径与独立记录方向一致地偏离，但仍缺一份能定性的官方口径。",
                "reason": (
                    f"{len(groups)} 个独立信源组给出的数值都"
                    f"{'低于' if direction == 'over' else '高于'}对外口径，"
                    f"方向一致，{word}假设未被推翻。"
                ),
            }
        if deviate:
            return {
                "falsification": "testable_but_unresolved",
                "contradicting": set(),
                "supporting": [c.clue_id for c in deviate],
                "gap": "偏离只出现在同一信源组，缺独立第二源。",
                "reason": "存在方向一致的偏离，但不足以排除口径差异。",
            }
        if all_facts:
            return {
                "falsification": "falsified",
                "contradicting": {c.clue_id for c in all_facts},
                "supporting": [],
                "gap": "",
                "reason": (
                    "独立记录没有呈现假设预测的偏离方向，"
                    "该假设缺乏支撑。"
                ),
            }
        return self._no_probe()

    def _fallback(self, hypothesis: Hypothesis, base: EvidenceBase,
                  triggers: list[Clue]) -> dict:
        entities = {e for c in triggers for e in c.entities}
        pool = [c for c in base.clues if set(c.entities) & entities] or triggers
        facts = [c for c in pool if c.kind in ("fact", "event")]
        if not facts:
            return self._no_probe()
        testable = self._looks_testable(hypothesis, facts)
        if not testable:
            return {
                "falsification": "untestable",
                "contradicting": set(),
                "supporting": [],
                "gap": "证据池里没有线索能触及这条预测。",
                "reason": "找不到可检验的线索，只能算叙事性猜测。",
            }
        supporting = [c.clue_id for c in facts]
        return {
            "falsification": "testable_but_unresolved",
            "contradicting": set(),
            "supporting": supporting,
            "gap": "现有证据触及了预测，但不足以排除同等解释的替代假设。",
            "reason": f"有 {len(supporting)} 条线索触及预测，未发现反证。",
        }

    @staticmethod
    def _looks_testable(hypothesis: Hypothesis, facts: list[Clue]) -> bool:
        pred = shingles(hypothesis.falsifiable_prediction)
        for c in facts:
            if overlap(pred, shingles(f"{c.content} {c.excerpt}")) >= 0.18:
                return True
            if any(e in hypothesis.falsifiable_prediction for e in c.entities):
                return True
        return False

    # ------------------------------------------------------------------
    @staticmethod
    def _clues_on(base: EvidenceBase, entity: str) -> list[Clue]:
        return [c for c in (base.clue(i) for i in base.entity_index.get(entity, [])) if c]

    @staticmethod
    def _unit_from(base: EvidenceBase, entity: str) -> Optional[str]:
        counts: dict[str, int] = defaultdict(int)
        for c in HeuristicBackend._clues_on(base, entity):
            for _v, u in _quantities(c):
                counts[u] += 1
        if not counts:
            return None
        return max(counts.items(), key=lambda kv: kv[1])[0]
