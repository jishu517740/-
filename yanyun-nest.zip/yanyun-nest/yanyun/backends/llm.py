"""LLM 后端：OpenAI 兼容协议（DeepSeek / Kimi / 本地 vLLM 都能接）。

三条纪律写在这里，而不是交给 prompt：
  1. 抽取结果的 excerpt 必须能在原文里逐字找到，否则丢弃（锚点强制）；
  2. 模型返回的 JSON 一定可能坏，坏了先修，修不好就重问，绝不让坏数据进图；
  3. 温度按阶段分离：拆线索要冷（0.1），出假设可以热（0.7），
     裁判必须最冷（0.0）——"大胆"和"小心"不能共用一个温度。
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Any, Optional

from ..graph import EvidenceBase, evidence_pool, summarize_for_hypotheses
from ..schema import Clue, Hypothesis, Verdict, stable_id, verdict_to_confidence
from ..textutil import contains_anchor, find_iso_dates, normalize_ws

EXTRACT_PROMPT = """从以下新闻中抽取线索。每条返回 JSON，字段：

- excerpt: 原文中逐字出现的片段（不得改写、不得拼接、不得省略中间的字）
- kind: fact / claim / event / timestamp
    fact = 可被独立验证的事实陈述（数字、记录、可查的动作）
    claim = 某方声称、主张、否认、预测、评价
    event = 发生了什么事
    timestamp = 纯时间信息
- entities: 涉及的实体名称列表（机构、项目、人名、系统名）
- content: 用一句话结构化重述该线索（不要加入原文没有的推断）
- timestamp: 若线索本身含时间信息，填 YYYY-MM-DD 或原文时间表述

要求：
1. 只抽取正文中显式出现的内容。你的角色是记录员，不是分析师。
2. 同一个句子里同时有"谁说了什么"和"发生了什么"时，拆成两条线索：
   一条 kind=claim（谁说的），一条 kind=event/fact（发生了什么）。
3. 每条 excerpt 必须能在正文里原样搜到，抽取前请自己核对。

新闻标题：{title}
新闻正文：{text}

只输出 JSON 列表，不要任何额外文字。"""

HYPOTHESIS_PROMPT = """你是一个新闻线索调查中的「假设生成器」。你的任务是**大胆**：
把分散线索里没人明说的那层关系提出来。但每一条都必须能被检验。

允许的发散类型（必须在 type 字段中标注其一）：
- bridge：多跳实体桥接（两条线索通过共享弱实体相连，路径长度 >= 2）
- counterfactual：时间/数值反事实（从结果倒推前置条件，或从数值分歧倒推谁在低报）
- motive：动机图谱（谁受益、谁受损、谁有隐瞒的动机、谁有动作能力）
- analogy：跨案例类比（结构相似的外部事件，必须注明类比来源；没有可靠来源就不要写）

每条假设必须返回 JSON，字段：
- hypothesis: 一句话陈述，要有信息量，不要写"可能存在某种关系"
- type: bridge / counterfactual / motive / analogy
- trigger_clue_ids: 触发这条假设的 clue_id 列表（至少 2 个，bridge 至少 3 个）
- falsifiable_prediction: 如果这条假设为真，**应该还能观察到什么**。
  必须具体、可检索、可验证：写清"去哪里找什么"。
  禁止写"需要进一步调查""有待观察"这类空话。
- confidence_prior: low / medium / high（只表示值得优先验证的程度，不是真值置信度）
- analogy_source: 仅 analogy 类型填写，说明类比的外部案例

额外纪律：
- 你不是在写新闻评论。每条假设都要能被一条具体的证据推翻。
- 优先处理"机器预检矛盾"里给出的硬信号（数值不一致、日期不一致、否认与记录并存、转载链）。
- 最多 {max_h} 条。宁可少，不要凑。

证据图摘要：
{summary}

只输出 JSON 列表。不要写结论段落。"""

ADJUDICATE_PROMPT = """你是证据裁判。只使用下列证据，不得引入任何外部知识。

待裁假设：{hypothesis}
假设类型：{type}
可证伪预测：{prediction}

证据池：
{evidence}

请按顺序输出 JSON：
1. contradiction_check：先检查证据池中是否存在与假设矛盾的时间、数字、归属或逻辑冲突。
   若有，列出 contradicting_clue_ids；若无，写 []。
2. claim_fact_confusion：检查假设是否把 kind=claim 的线索当作 kind=fact 使用。true/false。
3. falsification_result：
   - 可证伪预测是否被证据池中的某条线索直接否定？若被否定，填 falsified。
   - 证据池中是否存在能够检验该预测的线索？若存在但结果不明确，填 testable_but_unresolved。
   - 若证据池中没有任何线索能触及该预测，填 untestable。
4. supporting_clue_ids：真正支持假设的 clue_id 列表（不得包含 kind=claim 且被当作事实使用的线索）。
5. source_independence：single / multiple_independent / unknown。
   注意：不同域名不等于独立信源。若线索的 group 字段相同，说明它们来自同一通稿链。
6. verdict：supported / weakly_supported / contradicted / underdetermined。
   规则：falsified -> contradicted；untestable -> underdetermined；
   claim_fact_confusion=true -> 至多 weakly_supported；
   source_independence=single -> 至多 weakly_supported。
7. revised_confidence：confirmed / probable / speculative / rejected。
8. evidence_gap：缺少什么关键证据才能确认或推翻这条假设。
9. one_line_reason：一句话裁定理由。

注意：证据不足是合法且常见的结论。不要为了让报告好看而给 supported。

只输出 JSON，不要额外文字。"""


def _strip_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _balanced_slice(text: str, opener: str, closer: str) -> Optional[str]:
    start = text.find(opener)
    if start < 0:
        return None
    depth, in_str, escape = 0, False, False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == opener:
            depth += 1
        elif ch == closer:
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


def parse_json(text: str) -> Any:
    """把模型输出尽力解析成 JSON：去围栏、切平衡片段、去尾逗号。"""
    cleaned = _strip_fence(text)
    candidates = [cleaned]
    for opener, closer in (("[", "]"), ("{", "}")):
        chunk = _balanced_slice(cleaned, opener, closer)
        if chunk:
            candidates.append(chunk)
    for cand in candidates:
        for attempt in (cand, re.sub(r",\s*([\]}])", r"\1", cand)):
            try:
                return json.loads(attempt)
            except json.JSONDecodeError:
                continue
    raise ValueError(f"模型返回的不是合法 JSON：{text[:300]}")


class LLMBackend:
    name = "llm"

    def __init__(
        self,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        max_retries: int = 3,
        timeout: float = 90.0,
    ) -> None:
        self.model = model or os.getenv("YANYUN_MODEL", "deepseek-chat")
        self.api_key = (
            api_key
            or os.getenv("YANYUN_API_KEY")
            or os.getenv("DEEPSEEK_API_KEY")
            or os.getenv("OPENAI_API_KEY")
        )
        self.base_url = base_url or os.getenv("YANYUN_BASE_URL", "https://api.deepseek.com")
        self.max_retries = max_retries
        self.timeout = timeout
        self._client = None
        if not self.api_key:
            raise RuntimeError(
                "没有找到 API key。请设置 YANYUN_API_KEY（或 DEEPSEEK_API_KEY / OPENAI_API_KEY），"
                "或者改用 --engine heuristic 离线跑。"
            )

    # ------------------------------------------------------------------
    def _client_or_create(self):
        if self._client is None:
            from openai import OpenAI  # 延迟导入：离线模式不需要它

            self._client = OpenAI(
                api_key=self.api_key, base_url=self.base_url, timeout=self.timeout
            )
        return self._client

    def _complete(self, prompt: str, temperature: float) -> str:
        client = self._client_or_create()
        last_error: Optional[Exception] = None
        for attempt in range(self.max_retries):
            try:
                resp = client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=temperature,
                )
                return resp.choices[0].message.content or ""
            except Exception as exc:  # noqa: BLE001 - 网络/配额/模型问题都值得重试
                last_error = exc
                time.sleep(min(2 ** attempt, 8))
        raise RuntimeError(f"模型调用连续失败 {self.max_retries} 次：{last_error}")

    def _ask_json(self, prompt: str, temperature: float, expect: str) -> Any:
        raw = self._complete(prompt, temperature)
        try:
            return parse_json(raw)
        except ValueError as exc:
            repair = (
                f"你上一次的输出无法解析为 JSON（{exc}）。\n"
                f"请只输出合法的 {expect}，不要解释、不要 Markdown 围栏。\n"
                f"上一次输出：\n{raw[:1500]}"
            )
            return parse_json(self._complete(repair, 0.0))

    # ------------------------------------------------------------------
    def extract_clues(self, article_text: str, url: str, title: str,
                      default_year: Optional[int] = None) -> list[Clue]:
        prompt = EXTRACT_PROMPT.format(title=title, text=article_text[:6000])
        data = self._ask_json(prompt, temperature=0.1, expect="JSON 列表")
        if isinstance(data, dict):
            data = data.get("clues") or data.get("items") or []

        clues: list[Clue] = []
        for idx, item in enumerate(data):
            if not isinstance(item, dict):
                continue
            excerpt = str(item.get("excerpt", "")).strip()
            kind = str(item.get("kind", "fact")).strip().lower()
            if kind not in ("fact", "claim", "event", "timestamp"):
                kind = "fact"
            # 锚点强制：找不到原文的线索直接丢弃，这是防幻觉的第一道闸
            if not contains_anchor(article_text, excerpt):
                continue
            ts = item.get("timestamp") or None
            if not ts:
                dates = find_iso_dates(excerpt, default_year)
                ts = dates[0] if dates else None
            entities = item.get("entities") or []
            if isinstance(entities, str):
                entities = [e for e in re.split(r"[、,，;；]", entities) if e]
            clues.append(
                Clue(
                    clue_id=stable_id(f"{url}|{normalize_ws(excerpt)}", idx),
                    source_url=url,
                    source_title=title,
                    excerpt=excerpt,
                    kind=kind,
                    entities=[str(e).strip() for e in entities if str(e).strip()],
                    content=str(item.get("content") or excerpt)[:200],
                    timestamp=str(ts),
                    sentence_index=idx,
                )
            )
        return clues

    def generate_hypotheses(self, base: EvidenceBase, max_h: int = 5,
                            focus_entities: Optional[list[str]] = None) -> list[Hypothesis]:
        summary = summarize_for_hypotheses(base, focus_entities=focus_entities)
        prompt = HYPOTHESIS_PROMPT.format(max_h=max_h, summary=summary)
        data = self._ask_json(prompt, temperature=0.7, expect="JSON 列表")
        if isinstance(data, dict):
            data = data.get("hypotheses") or []

        out: list[Hypothesis] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            hypothesis = str(item.get("hypothesis", "")).strip()
            prediction = str(item.get("falsifiable_prediction", "")).strip()
            triggers = [str(x) for x in (item.get("trigger_clue_ids") or [])]
            if not hypothesis or not prediction or not triggers:
                continue
            htype = str(item.get("type", "bridge")).strip().lower()
            if htype not in ("bridge", "counterfactual", "motive", "analogy"):
                htype = "bridge"
            out.append(
                Hypothesis(
                    hypothesis=hypothesis,
                    type=htype,
                    trigger_clue_ids=triggers,
                    falsifiable_prediction=prediction,
                    confidence_prior=str(item.get("confidence_prior", "medium")),
                    analogy_source=item.get("analogy_source"),
                )
            )
        return out[:max_h]

    def adjudicate(self, hypothesis: Hypothesis, base: EvidenceBase,
                   pool_text: str) -> Verdict:
        prompt = ADJUDICATE_PROMPT.format(
            hypothesis=hypothesis.hypothesis,
            type=hypothesis.type,
            prediction=hypothesis.falsifiable_prediction,
            evidence=pool_text,
        )
        data = self._ask_json(prompt, temperature=0.0, expect="JSON 对象")
        if not isinstance(data, dict):
            data = {}

        verdict = str(data.get("verdict", "underdetermined"))
        if verdict not in ("supported", "weakly_supported", "contradicted", "underdetermined"):
            verdict = "underdetermined"
        confidence = str(data.get("revised_confidence", verdict_to_confidence(verdict)))
        if confidence not in ("confirmed", "probable", "speculative", "rejected"):
            confidence = verdict_to_confidence(verdict)

        return Verdict(
            hypothesis=hypothesis.hypothesis,
            type=hypothesis.type,
            falsifiable_prediction=hypothesis.falsifiable_prediction,
            verdict=verdict,
            revised_confidence=confidence,
            supporting_clue_ids=[str(x) for x in (data.get("supporting_clue_ids") or [])],
            contradicting_clue_ids=[str(x) for x in (data.get("contradicting_clue_ids") or [])],
            source_independence=str(data.get("source_independence", "unknown")),
            claim_fact_confusion=bool(data.get("claim_fact_confusion", False)),
            falsification_result=str(data.get("falsification_result", "untestable")),
            evidence_gap=str(data.get("evidence_gap", "")),
            one_line_reason=str(data.get("one_line_reason", "")),
        )
