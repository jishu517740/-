"""证据图：线索 → 节点，关系 → 边。

原稿的 `build_evidence_graph` 只有"共享实体"一种边，末尾一行注释写着
"时间边此处简化"，等于没有。但新闻里真正的"隐藏秘密"恰好藏在三种
硬信号里，所以这里把它们全部建成一等边：

    数值冲突  同一实体的同一量纲出现不同数值（瞒报 / 口径打架 / 笔误）
    时间冲突  同一实体的同一动作被指向不同日期（前后矛盾 / 被推迟）
    转载链    不同域名但同源文本（"三源交叉"的假象）

这三种都是**代码能算的**，不需要模型。凡代码能算的，就不该交给模型猜——
这是"小心求证"能被验收的前提。
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable, Optional

import re

import networkx as nx

from .schema import Clue
from .textutil import (
    find_quantities,
    jaccard,
    normalize_ws,
    registered_domain,
    shingles,
)

# 会被误当成"多源交叉"的转载判定阈值
SYNDICATION_JACCARD = 0.35
MIN_ANCHOR_LEN = 12

# 需要对齐日期的动作词
_ACTION_WORDS = ("投产", "开工", "启动", "签署", "发布", "上线", "交付", "竣工", "停产", "复产")

# 「否认」与「有记录」同时出现在同一实体身上 —— 这是最接近"瞒报"的硬信号
_NEGATION = re.compile(
    r"无人(?:受伤|伤亡)|未(?:发生|造成)|没有(?:人员)?(?:受伤|伤亡)|否认|不存在|并非|不予确认"
)
_POSITIVE_FACT = re.compile(r"受伤|伤亡|死亡|事故|违规|罚款|停产|起火|泄漏|超支|延期|投诉")


@dataclass
class Contradiction:
    """机器预检出的矛盾，供裁判引用（不是结论，只是信号）。"""

    kind: str                    # numeric / temporal / negation / duplicate
    clue_a: str
    clue_b: str
    entity: Optional[str]
    detail: str
    action: Optional[str] = None  # temporal 型矛盾对应的动作词
    unit: Optional[str] = None    # numeric 型矛盾的量纲
    instance: Optional[str] = None  # numeric 型矛盾的实例主键（编号或日期）

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "clue_a": self.clue_a,
            "clue_b": self.clue_b,
            "entity": self.entity,
            "detail": self.detail,
            "action": self.action,
            "unit": self.unit,
            "instance": self.instance,
        }


@dataclass
class EvidenceBase:
    """证据台：线索集合 + 图 + 预检结果。"""

    clues: list[Clue]
    graph: nx.MultiDiGraph
    contradictions: list[Contradiction] = field(default_factory=list)
    entity_index: dict[str, list[str]] = field(default_factory=dict)

    def clue(self, clue_id: str) -> Optional[Clue]:
        for c in self.clues:
            if c.clue_id == clue_id:
                return c
        return None

    def by_id(self) -> dict[str, Clue]:
        return {c.clue_id: c for c in self.clues}


# ----------------------------------------------------------------------
# 来源独立性：域名归组 + 文本近重复合并
# ----------------------------------------------------------------------

class _UnionFind:
    def __init__(self) -> None:
        self._parent: dict[str, str] = {}

    def find(self, x: str) -> str:
        self._parent.setdefault(x, x)
        while self._parent[x] != x:
            self._parent[x] = self._parent[self._parent[x]]
            x = self._parent[x]
        return x

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self._parent[rb] = ra


def assign_independence_groups(clues: list[Clue]) -> dict[str, str]:
    """给每条线索打上独立性分组。

    规则（由宽到严）：
      1. 同注册域名 → 同一组（同一家媒体的多篇报道不算独立信源）。
      2. 跨域名但文本高度重合 → 同一组（转载同一通讯社通稿）。
    返回 {clue_id: group_id}。
    """
    uf = _UnionFind()
    domain_of: dict[str, str] = {}
    for c in clues:
        dom = c.source_domain or registered_domain(c.source_url) or "unknown"
        domain_of[c.clue_id] = dom

    # 先按域名成组
    by_domain: dict[str, list[Clue]] = defaultdict(list)
    for c in clues:
        by_domain[domain_of[c.clue_id]].append(c)

    domains = sorted(by_domain)
    for dom in domains:
        uf.find(f"d:{dom}")

    # 再看跨域文本重合：以"整篇 excerpt 拼接"的 shingle 集合比相似度
    domain_shingles = {
        dom: shingles("".join(normalize_ws(c.excerpt) for c in items))
        for dom, items in by_domain.items()
    }
    shared_anchor = defaultdict(set)  # 归一化锚点 -> 域名集合
    for c in clues:
        key = normalize_ws(c.excerpt)
        if len(key) >= MIN_ANCHOR_LEN:
            shared_anchor[key].add(domain_of[c.clue_id])

    for i, a in enumerate(domains):
        for b in domains[i + 1 :]:
            sim = jaccard(domain_shingles[a], domain_shingles[b])
            if sim >= SYNDICATION_JACCARD:
                uf.union(f"d:{a}", f"d:{b}")

    # 同一整句在两个域名逐字出现，也视为同源（短稿相似度会低于阈值）
    for _anchor, doms in shared_anchor.items():
        doms = sorted(doms)
        for extra in doms[1:]:
            uf.union(f"d:{doms[0]}", f"d:{extra}")

    groups: dict[str, str] = {}
    label: dict[str, str] = {}
    for c in clues:
        root = uf.find(f"d:{domain_of[c.clue_id]}")
        label.setdefault(root, f"G{len(label) + 1}")
        groups[c.clue_id] = label[root]
    return groups


# ----------------------------------------------------------------------
# 预检：数值冲突 / 时间冲突
# ----------------------------------------------------------------------

def _clue_text(clue: Clue) -> str:
    """content 与 excerpt 可能是同一句，拼之前先去掉重复，否则数字会被数两遍。"""
    content, excerpt = clue.content or "", clue.excerpt or ""
    return content if content == excerpt else f"{content} {excerpt}"


def instance_key(clue: Clue) -> str:
    """实例主键：有编号用编号，没编号用日期，都没有才归到 unknown。

    这一条决定了"横向比什么"：
      同一实例的多个数值 = 矛盾（可判真假）
      不同实例的多个数值 = 递进（那是纵向的事，交给链层）
    """
    number = _doc_number(clue.excerpt)
    if number is not None:
        return f"№{number}"
    if clue.timestamp:
        return f"@{clue.timestamp[:10]}"
    return "unknown"


def detect_contradictions(clues: list[Clue]) -> list[Contradiction]:
    out: list[Contradiction] = []
    by_entity: dict[str, list[Clue]] = defaultdict(list)
    for c in clues:
        for e in c.entities:
            by_entity[e].append(c)

    for entity, items in by_entity.items():
        # --- 数值冲突：同一实体 + 同一实例 + 同一单位 + 不同数值 ---
        buckets: dict[tuple[str, str], list[tuple[float, Clue]]] = defaultdict(list)
        for c in items:
            instance = instance_key(c)
            for value, unit in find_quantities(_clue_text(c)):
                buckets[(unit, instance)].append((value, c))
        for (unit, instance), pairs in buckets.items():
            distinct: dict[float, list[Clue]] = defaultdict(list)
            for value, c in pairs:
                if c not in distinct[round(value, 4)]:
                    distinct[round(value, 4)].append(c)
            if len(distinct) < 2:
                continue
            values = sorted(distinct)
            low, high = values[0], values[-1]
            labeled = []
            for value in values:
                clue = distinct[value][0]
                mark = "（某方声称）" if clue.kind == "claim" else ""
                labeled.append(f"{value:g}{mark}")
            where = "" if instance == "unknown" else f"（{instance}）"
            out.append(
                Contradiction(
                    kind="numeric",
                    clue_a=distinct[low][0].clue_id,
                    clue_b=distinct[high][0].clue_id,
                    entity=entity,
                    detail=(
                        f"{entity} 的 {unit} 口径出现 {len(values)} 个值"
                        f"{where}：{'、'.join(labeled)}"
                    ),
                    unit=unit,
                    instance=instance,
                )
            )

        # --- 时间冲突：同一实体的同一动作指向不同日期 ---
        # 例外：两份公告的编号不同 → 是同一动作的两次发布（序列），不是矛盾。
        # 这正是"编号是天然主键"能派上用场的地方。
        actions: dict[str, list[Clue]] = defaultdict(list)
        for c in items:
            if not c.timestamp:
                continue
            text = f"{c.content}"
            for word in _ACTION_WORDS:
                if word in text:
                    actions[word].append(c)
        for word, with_ts in actions.items():
            dates = {c.timestamp for c in with_ts}
            if len(dates) > 1:
                ordered = sorted(with_ts, key=lambda c: c.timestamp or "")
                first, last = ordered[0], ordered[-1]
                n_first = _doc_number(first.excerpt)
                n_last = _doc_number(last.excerpt)
                if n_first and n_last and n_first != n_last:
                    continue  # 不同编号 = 同一动作的两次发布，序列而非矛盾
                out.append(
                    Contradiction(
                        kind="temporal",
                        clue_a=first.clue_id,
                        clue_b=last.clue_id,
                        entity=entity,
                        detail=f"{entity} 的「{word}」日期不一致：{' vs '.join(sorted(dates))}",
                        action=word,
                    )
                )

        # --- 否认 vs 记录：同一实体上"否认"与"有记录的负面事实"并存 ---
        negations = [c for c in items if _NEGATION.search(c.content or c.excerpt)]
        positives = [
            c for c in items
            if c.kind in ("fact", "event") and _POSITIVE_FACT.search(c.content or c.excerpt)
            and not _NEGATION.search(c.content or c.excerpt)
        ]
        for claim in negations:
            for fact in positives:
                if claim.clue_id == fact.clue_id:
                    continue
                out.append(
                    Contradiction(
                        kind="negation",
                        clue_a=claim.clue_id,
                        clue_b=fact.clue_id,
                        entity=entity,
                        detail=(
                            f"{entity} 一方否认（「{claim.content[:24]}」），"
                            f"但另一方留下了相反记录（「{fact.content[:24]}」）"
                        ),
                    )
                )
    return out


def detect_duplicates(clues: list[Clue]) -> list[Contradiction]:
    """同源转载：不同域名但整句逐字相同 —— 用来打掉"多源交叉"的假象。"""
    out: list[Contradiction] = []
    seen: dict[str, list[Clue]] = defaultdict(list)
    for c in clues:
        key = normalize_ws(c.excerpt)
        if len(key) >= MIN_ANCHOR_LEN:
            seen[key].append(c)
    reported: set[tuple[str, str]] = set()
    for _key, items in seen.items():
        doms = {c.source_domain for c in items}
        if len(doms) < 2:
            continue
        for i, a in enumerate(items):
            for b in items[i + 1 :]:
                if a.source_domain == b.source_domain:
                    continue
                pair = tuple(sorted((a.source_domain or "", b.source_domain or "")))
                if pair in reported:
                    continue
                reported.add(pair)
                out.append(
                    Contradiction(
                        kind="duplicate",
                        clue_a=a.clue_id,
                        clue_b=b.clue_id,
                        entity=None,
                        detail=f"{pair[0]} 与 {pair[1]} 出现逐字相同的表述，疑为通稿转载",
                    )
                )
    return out


# ----------------------------------------------------------------------
# 建图
# ----------------------------------------------------------------------

# 机构名的常见尾巴，用于把"星港物流"和"星港物流公司"合并成同一实体
_ORG_TAILS = ("股份有限公司", "有限责任公司", "有限公司", "公司", "集团", "控股")


def _entity_key(name: str) -> str:
    key = name
    for tail in _ORG_TAILS:
        if key.endswith(tail) and len(key) > len(tail) + 1:
            key = key[: -len(tail)]
            break
    return key


def _canonicalize_entities(clues: list[Clue]) -> None:
    """同一机构的不同写法合并，否则证据图会被自己拆成两半。"""
    counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for c in clues:
        for e in c.entities:
            counts[_entity_key(e)][e] += 1

    canonical: dict[str, str] = {}
    for key, variants in counts.items():
        # 取出现次数最多的写法；并列时取更长的（信息更多）
        best = sorted(variants.items(), key=lambda kv: (-kv[1], -len(kv[0])))[0][0]
        for variant in variants:
            canonical[variant] = best

    for c in clues:
        merged: list[str] = []
        for e in c.entities:
            name = canonical.get(e, e)
            if name not in merged:
                merged.append(name)
        c.entities = merged


def _doc_number(text: str) -> Optional[int]:
    """抽出公告编号里的序号，例如「〔2026〕第002号」→ 2。"""
    m = re.search(r"第\s*(\d+)\s*号", text or "")
    return int(m.group(1)) if m else None


def build_evidence_base(clues: list[Clue]) -> EvidenceBase:
    _canonicalize_entities(clues)
    groups = assign_independence_groups(clues)
    for c in clues:
        c.independence_group = groups[c.clue_id]
        if not c.source_domain:
            c.source_domain = registered_domain(c.source_url)

    G = nx.MultiDiGraph()
    entity_index: dict[str, list[str]] = defaultdict(list)

    for c in clues:
        G.add_node(c.clue_id, node_type="clue", **c.to_dict())
        for e in c.entities:
            entity_index[e].append(c.clue_id)
            ent_node = f"E:{e}"
            if not G.has_node(ent_node):
                G.add_node(ent_node, node_type="entity", name=e)
            G.add_edge(c.clue_id, ent_node, rel="涉及", weight=1.0)

    # 共享实体 → 共指边（多跳桥接的种子）
    for e, ids in entity_index.items():
        for i, a in enumerate(ids):
            for b in ids[i + 1 :]:
                if a == b:
                    continue
                G.add_edge(a, b, rel=f"共享实体:{e}", entity=e, weight=1.0)

    # 时间边：同实体、都有时间戳 → 先后关系
    by_id = {c.clue_id: c for c in clues}
    for e, ids in entity_index.items():
        timed = [by_id[i] for i in ids if by_id[i].timestamp]
        timed.sort(key=lambda c: c.timestamp or "")
        for a, b in zip(timed, timed[1:]):
            if a.timestamp != b.timestamp:
                G.add_edge(a.clue_id, b.clue_id, rel="先于", entity=e, weight=0.5)

    contradictions = detect_contradictions(clues) + detect_duplicates(clues)
    for con in contradictions:
        if G.has_node(con.clue_a) and G.has_node(con.clue_b):
            G.add_edge(
                con.clue_a, con.clue_b, rel=f"矛盾:{con.kind}", entity=con.entity, weight=2.0
            )

    return EvidenceBase(
        clues=clues,
        graph=G,
        contradictions=contradictions,
        entity_index=dict(entity_index),
    )


# ----------------------------------------------------------------------
# 两种视图：给假设生成器（全局摘要）/ 给裁判（局部证据池）
# ----------------------------------------------------------------------

def summarize_for_hypotheses(base: EvidenceBase, focus_entities: Optional[list[str]] = None) -> str:
    """把证据图压成生成器可读的摘要：实体索引 + 线索明细 + 预检矛盾。"""
    lines: list[str] = ["## 实体 → 线索索引"]
    index = sorted(base.entity_index.items(), key=lambda kv: -len(kv[1]))
    for entity, ids in index:
        if focus_entities and entity not in focus_entities:
            continue
        lines.append(f"- {entity}: {', '.join(ids)}")

    lines.append("\n## 线索明细")
    for c in base.clues:
        if focus_entities and not (set(c.entities) & set(focus_entities)):
            continue
        ts = f" | ts={c.timestamp}" if c.timestamp else ""
        lines.append(
            f"[{c.clue_id}] ({c.kind}) {c.content}{ts} "
            f"| entities={c.entities} | source={c.source_domain} "
            f"| group={c.independence_group} | excerpt={c.excerpt[:100]}"
        )

    if base.contradictions:
        lines.append("\n## 机器预检矛盾（硬信号，不是结论）")
        for con in base.contradictions:
            lines.append(
                f"- [{con.kind}] {con.clue_a} ↔ {con.clue_b}：{con.detail}"
            )
    else:
        lines.append("\n## 机器预检矛盾\n- 无")
    return "\n".join(lines)


def evidence_pool(
    base: EvidenceBase, clue_ids: Iterable[str], hops: int = 1, max_lines: int = 60
) -> str:
    """裁判用的局部证据池：触发线索 + 邻域（不跨越实体噪声全图）。"""
    node_set = {c for c in clue_ids if base.graph.has_node(c)}
    frontier = set(node_set)
    for _ in range(max(hops, 0)):
        new_frontier: set[str] = set()
        for node in frontier:
            for nb in base.graph.successors(node):
                if not str(nb).startswith("E:") and nb not in node_set:
                    new_frontier.add(nb)
        node_set |= new_frontier
        frontier = new_frontier

    by_id = base.by_id()
    lines: list[str] = []
    for cid in sorted(node_set):
        c = by_id.get(cid)
        if c is None:
            continue
        ts = f" | ts={c.timestamp}" if c.timestamp else ""
        lines.append(
            f"[{cid}] ({c.kind}) {c.content}{ts} "
            f"| source={c.source_domain} | group={c.independence_group} "
            f"| excerpt={c.excerpt[:120]}"
        )
        if len(lines) >= max_lines:
            lines.append("...(证据池已截断)")
            break

    related = [
        con
        for con in base.contradictions
        if con.clue_a in node_set or con.clue_b in node_set
    ]
    if related:
        lines.append("## 预检矛盾（与本次触发线索相关）")
        for con in related:
            lines.append(f"- [{con.kind}] {con.clue_a} ↔ {con.clue_b}：{con.detail}")
    return "\n".join(lines)


def entity_neighbors(base: EvidenceBase, entity: str) -> list[str]:
    return list(base.entity_index.get(entity, []))
