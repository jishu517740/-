"""输入层：链接 / 本地文件 / 目录 → 文章列表。

设计上刻意**不做全网爬取**，只处理你显式交给它的材料。
原因不是技术限制，而是纪律：材料的边界就是推论的边界，
一只会自己乱抓的爬虫会让"证据池"失去可审计性。
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from .textutil import registered_domain


@dataclass
class Article:
    url: str
    title: str
    text: str
    published: Optional[str] = None
    source_domain: str = field(default="")
    # 权重等级：A 官方一手 / B 多家独立通讯社 / C 单一媒体 / D 匿名与社交
    tier: str = "C"

    def __post_init__(self) -> None:
        if not self.source_domain:
            self.source_domain = registered_domain(self.url) or ""


class FetchError(RuntimeError):
    pass


_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def fetch_url(url: str, timeout: float = 20.0) -> Article:
    """抓一篇正文。失败会抛 FetchError，让调用方决定跳过还是终止。"""
    import requests
    from bs4 import BeautifulSoup

    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": _USER_AGENT})
        resp.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise FetchError(f"抓取失败 {url}：{exc}") from exc

    # 中文站点常见编码问题
    if not resp.encoding or resp.encoding.lower() == "iso-8859-1":
        resp.encoding = resp.apparent_encoding or "utf-8"

    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()

    title = (soup.title.string if soup.title and soup.title.string else url).strip()

    node = soup.find("article") or soup.find("main") or soup
    paragraphs = [p.get_text(" ", strip=True) for p in node.find_all("p")]
    text = "\n".join(p for p in paragraphs if len(p) >= 12)
    if len(text) < 120:
        text = node.get_text("\n", strip=True)

    if len(text) < 80:
        raise FetchError(f"正文过短，可能是反爬或动态渲染：{url}")
    return Article(url=url, title=title, text=text)


def load_articles(path: str | Path) -> list[Article]:
    """支持三种输入：json 清单 / 单个文本 / 目录（批量文本）。"""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)

    if path.is_file() and path.suffix.lower() == ".json":
        raw = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            raw = raw.get("articles") or raw.get("items") or []
        articles: list[Article] = []
        for i, item in enumerate(raw):
            url = str(item.get("url") or f"file://local/{i}")
            articles.append(
                Article(
                    url=url,
                    title=str(item.get("title") or f"材料 {i + 1}"),
                    text=str(item.get("text") or ""),
                    published=item.get("published"),
                    tier=str(item.get("tier") or "C").upper()[:1],
                )
            )
        return articles

    files = [path] if path.is_file() else sorted(
        p for p in path.iterdir() if p.suffix.lower() in (".txt", ".md")
    )
    articles = []
    for f in files:
        text = f.read_text(encoding="utf-8", errors="replace")
        articles.append(
            Article(
                url=f"file://{f.name}",
                title=f.stem,
                text=text,
            )
        )
    return articles


def resolve_inputs(items: list[str]) -> list[Article]:
    """命令行参数 → 文章列表。既可以是路径，也可以直接是 http(s) 链接。"""
    articles: list[Article] = []
    errors: list[str] = []
    for item in items:
        if item.startswith(("http://", "https://")):
            try:
                articles.append(fetch_url(item))
            except FetchError as exc:
                errors.append(str(exc))
        else:
            articles.extend(load_articles(item))
    if not articles and errors:
        raise FetchError("；".join(errors))
    for article in articles:
        if not article.text.strip():
            errors.append(f"空正文：{article.url}")
    return articles
