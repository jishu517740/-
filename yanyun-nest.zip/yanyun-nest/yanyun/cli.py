"""命令行入口。

    python -m yanyun run samples/articles.json --engine heuristic
    python -m yanyun run https://example.com/a.html --engine llm
    python -m yanyun doctor
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .backends.heuristic import HeuristicBackend
from .fetch import FetchError, resolve_inputs
from .pipeline import investigate
from .report import render_markdown, write_outputs


def _build_backend(engine: str, extra_suffixes: tuple[str, ...] = ()):
    if engine == "heuristic":
        return HeuristicBackend(extra_suffixes=extra_suffixes)
    from .backends.llm import LLMBackend

    return LLMBackend()


def _cmd_run(args: argparse.Namespace) -> int:
    try:
        articles = resolve_inputs(args.inputs)
    except (FileNotFoundError, FetchError) as exc:
        print(f"[输入错误] {exc}", file=sys.stderr)
        return 2

    if args.limit:
        articles = articles[: args.limit]
    if not articles:
        print("[输入错误] 没有可用材料。", file=sys.stderr)
        return 2

    focus = None
    if args.focus:
        focus = [x.strip() for part in args.focus for x in part.split(",") if x.strip()]

    topic = None
    if args.topic:
        try:
            from .topics import load_topic

            topic = load_topic(args.topic)
        except (OSError, ValueError) as exc:
            print(f"[题材包错误] {exc}", file=sys.stderr)
            return 2

    try:
        backend = _build_backend(
            args.engine, tuple(topic.name_suffixes) if topic else ()
        )
    except RuntimeError as exc:
        print(f"[后端错误] {exc}", file=sys.stderr)
        return 3

    investigation = investigate(
        articles,
        backend,
        max_hypotheses=args.max_hypotheses,
        focus_entities=focus,
        quota_ratio=args.quota_ratio,
        workers=args.workers,
        topic=topic,
    )

    if args.stdout:
        print(render_markdown(investigation, title=args.title))
        return 0

    md_path, json_path = write_outputs(investigation, args.out, title=args.title)
    print(f"报告：{md_path}")
    print(f"数据：{json_path}")
    print()
    print(f"材料 {len(articles)} 篇 → 线索 {len(investigation.base.clues)} 条 "
          f"→ 硬信号 {len(investigation.base.contradictions)} 个 "
          f"→ 假设 {len(investigation.hypotheses)} 条")
    print(investigation.quota.note)
    for verdict in investigation.verdicts:
        mark = {
            "confirmed": "●", "probable": "◐", "speculative": "○", "rejected": "×"
        }.get(verdict.revised_confidence, "?")
        print(f"  {mark} [{verdict.revised_confidence}] {verdict.hypothesis[:64]}")
    return 0


def _cmd_doctor(_args: argparse.Namespace) -> int:
    import importlib

    print("燕云推案 · 环境自检")
    print(f"  Python：{sys.version.split()[0]}")
    ok = True
    for module in ("networkx", "requests", "bs4", "openai"):
        try:
            mod = importlib.import_module(module)
            version = getattr(mod, "__version__", "?")
            print(f"  {module:<10} OK  {version}")
        except Exception as exc:  # noqa: BLE001
            ok = False
            print(f"  {module:<10} 缺失：{exc}")

    import os

    key = (
        os.getenv("YANYUN_API_KEY")
        or os.getenv("DEEPSEEK_API_KEY")
        or os.getenv("OPENAI_API_KEY")
    )
    print(f"  模型 key：{'已配置' if key else '未配置（可用 --engine heuristic 离线跑）'}")
    print(f"  base_url：{os.getenv('YANYUN_BASE_URL', 'https://api.deepseek.com')}")
    print(f"  model：{os.getenv('YANYUN_MODEL', 'deepseek-chat')}")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yanyun", description="燕云推案：大胆假设，小心求证。"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="跑一次调查")
    run.add_argument("inputs", nargs="+", help="文件路径 / 目录 / 链接")
    run.add_argument("--engine", choices=["heuristic", "llm"], default="heuristic",
                     help="heuristic=离线确定性；llm=接真模型")
    run.add_argument("--max-hypotheses", type=int, default=5)
    run.add_argument("--focus", action="append", default=None,
                     help="只关注这些实体（可多次，逗号分隔）")
    run.add_argument("--quota-ratio", type=float, default=0.5,
                     help="证伪配额比例，默认 0.5")
    run.add_argument("--workers", type=int, default=4, help="并发的抽取线程数")
    run.add_argument("--limit", type=int, default=0, help="只用前 N 篇材料")
    run.add_argument("--out", default="out", help="输出目录")
    run.add_argument("--topic", default=None, help="题材包 JSON（如 topics/台海.json）")
    run.add_argument("--title", default="燕云推案 · 推论报告")
    run.add_argument("--stdout", action="store_true", help="直接打印到终端，不写文件")
    run.set_defaults(func=_cmd_run)

    doctor = sub.add_parser("doctor", help="检查依赖与配置")
    doctor.set_defaults(func=_cmd_doctor)
    return parser


def main(argv: list[str] | None = None) -> int:
    try:  # .env 可选：没有 python-dotenv 也能跑
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
