"""文本工具：分句、日期归一、数量抽取、近似重复检测。

原稿在这里是空的（`build_evidence_graph` 里写着"此处简化"），
而"时间矛盾检测"和"来源独立性评估"两道关卡全靠这些基础能力。
"""
from __future__ import annotations

import re
from datetime import date
from typing import Iterable, Optional
from urllib.parse import urlparse

# 常见二级后缀，用于取"注册域名"（不是取最后两段就完事）
_SECOND_LEVEL = {
    "com.cn", "net.cn", "org.cn", "gov.cn", "edu.cn", "ac.cn",
    "co.uk", "org.uk", "com.hk", "com.tw", "co.jp",
}

_SENT_SPLIT = re.compile(r"(?<=[。！？!?；;])\s*|\n+")

_QUANTITY = re.compile(
    r"(\d+(?:\.\d+)?)\s*(亿元|万元|元|%|个百分点|架次|艘次|人次|万台|人|名|吨|公里|海里|小时|天|岁|倍)"
)

_DATE_PATTERNS = (
    # 2026-11-13 / 2026/11/13 / 2026.11.13
    re.compile(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})"),
    # 2026年11月13日
    re.compile(r"(\d{4})\s*年\s*(\d{1,2})\s*月(?:\s*(\d{1,2})\s*日)?"),
    # 11月13日（需要外部年份）
    re.compile(r"(?<!\d)(\d{1,2})\s*月\s*(\d{1,2})\s*日"),
)


def normalize_ws(text: str) -> str:
    """去掉所有空白，用于锚点比对（排版换行不应导致误判）。"""
    return re.sub(r"\s+", "", text or "")


def contains_anchor(article_text: str, excerpt: str) -> bool:
    """excerpt 是否逐字出现在原文中（忽略空白差异）。"""
    needle = normalize_ws(excerpt)
    return bool(needle) and needle in normalize_ws(article_text)


def split_sentences(text: str) -> list[str]:
    parts = (p.strip() for p in _SENT_SPLIT.split(text or ""))
    return [p for p in parts if len(p) >= 6]


def registered_domain(url: str) -> Optional[str]:
    """取注册域名：news.example.com.cn -> example.com.cn。"""
    try:
        host = (urlparse(url).hostname or "").lower()
    except ValueError:
        return None
    if not host:
        return None
    host = host.removeprefix("www.")
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    if ".".join(labels[-2:]) in _SECOND_LEVEL:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def find_iso_dates(text: str, default_year: Optional[int] = None) -> list[str]:
    """抽出所有可解析的日期，统一成 YYYY-MM-DD（无法补全年份的跳过）。"""
    found: list[str] = []
    for pattern in _DATE_PATTERNS[:2]:
        for m in pattern.finditer(text or ""):
            y, mo = int(m.group(1)), int(m.group(2))
            d = int(m.group(3)) if m.lastindex and m.lastindex >= 3 and m.group(3) else 1
            found.append(_safe_iso(y, mo, d))
    if default_year:
        for m in _DATE_PATTERNS[2].finditer(text or ""):
            found.append(_safe_iso(default_year, int(m.group(1)), int(m.group(2))))
    # 去重并保序
    seen, out = set(), []
    for value in found:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def _safe_iso(y: int, m: int, d: int) -> Optional[str]:
    try:
        return date(y, m, d).isoformat()
    except ValueError:
        return None


def find_quantities(text: str) -> list[tuple[float, str]]:
    """抽出 (数值, 单位) 对，用于数值矛盾检测。"""
    return [(float(m.group(1)), m.group(2)) for m in _QUANTITY.finditer(text or "")]


def shingles(text: str, size: int = 8) -> set[str]:
    """字符 n-gram，用于判断两篇报道是否同一篇通稿。"""
    clean = re.sub(r"[\s，。！？、；：“”‘’()（）\-—…·]", "", text or "")
    if len(clean) <= size:
        return {clean} if clean else set()
    return {clean[i : i + size] for i in range(len(clean) - size + 1)}


def jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def overlap(a: set[str], b: set[str]) -> float:
    """相对 a 的覆盖率：a 有多少比例出现在 b 里（用于"这段原文能在别处找到"）。"""
    if not a:
        return 0.0
    return len(a & b) / len(a)


_COMPARATORS = {
    "低于": ("lt",),
    "少于": ("lt",),
    "小于": ("lt",),
    "高于": ("gt",),
    "超过": ("gt",),
    "大于": ("gt",),
    "等于": ("eq",),
}


def comparators_in(text: str) -> list[str]:
    return [word for word in _COMPARATORS if word in (text or "")]
