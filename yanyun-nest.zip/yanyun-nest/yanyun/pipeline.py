"""流水线：证据台 → 建图 → 大胆假设 → 小心求证 → 收敛。

这里是原稿最缺的一层。四个函数片段各自都能看懂，但拼不成一个**有结论**
的系统，因为没有"收敛"这一步：

  · 代码守门：凡是能用规则算准的字段（锚点、独立性、claim/fact 混淆），
    一律由代码覆写模型的判断，模型只负责它真正擅长的语言理解。
  · 证伪配额：doc 引用的协议要求"至少一半候选假设先被证伪才允许输出结论"。
    达不到就整体降级——这是项目里唯一一条防止"批量生产自信叙事"的闸门。
"""
from __future__ import annotations

import math
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Optional

from .backends.base import Backend
from .chain import ChainReport, build_chain_report
from .fetch import Article
from .graph import EvidenceBase, build_evidence_base, evidence_pool
from .schema import (
    Clue,
    Hypothesis,
    Verdict,
    clamp_confidence,
    confidence_rank,
    verdict_to_confidence,
)
from .textutil import find_iso_dates
from .topics import Topic


@dataclass
class QuotaResult:
    """证伪配额的执行结果。"""

    required: int
    actual: int
    total: int
    met: bool
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "required": self.required,
            "actual": self.actual,
            "total": self.total,
            "met": self.met,
            "note": self.note,
        }


@dataclass
class Investigation:
    articles: list[Article]
    base: EvidenceBase
    hypotheses: list[Hypothesis]
    verdicts: list[Verdict]
    quota: QuotaResult
    backend_name: str
    chain: Optional[ChainReport] = None
    warnings: list[str] = field(default_factory=list)

    # 便于报告层取数
    def source_groups(self) -> dict[str, list[str]]:
        groups: dict[str, list[str]] = {}
        for clue in self.base.clues:
            key = clue.independence_group or "?"
            groups.setdefault(key, []).append(clue.source_domain or "?")
        return groups


def _extract_all(backend: Backend, articles: list[Article], workers: int = 4) -> list[Clue]:
    def one(article: Article) -> list[Clue]:
        year = None
        if article.published:
            dates = find_iso_dates(article.published)
            year = int(dates[0][:4]) if dates else None
        return backend.extract_clues(article.text, article.url, article.title, default_year=year)

    if workers <= 1:
        batches = [one(a) for a in articles]
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            batches = list(pool.map(one, articles))

    tier_of = {a.url: a.tier for a in articles}
    clues: list[Clue] = []
    seen: set[str] = set()
    for batch in batches:
        for clue in batch:
            if clue.clue_id in seen:
                continue
            seen.add(clue.clue_id)
            clue.tier = clue.tier or tier_of.get(clue.source_url, "C")
            clues.append(clue)
    return clues


def _guard(hypothesis: Hypothesis, verdict: Verdict, base: EvidenceBase) -> Verdict:
    """代码守门：把能用规则算准的字段覆写掉。

    模型经常"看起来谨慎"却给出偏高置信。这里的规则只做一件事：
    证据不足以支撑的结论，一级都不许升。
    """
    by_id = base.by_id()
    triggers = [by_id[i] for i in hypothesis.trigger_clue_ids if i in by_id]

    # 1) 不存在的 clue_id 直接剔除（模型会编 id）
    verdict.supporting_clue_ids = [i for i in verdict.supporting_clue_ids if i in by_id]
    verdict.contradicting_clue_ids = [
        i for i in verdict.contradicting_clue_ids if i in by_id
    ]

    # 2) claim/fact 混淆：触发线索若全是"某方声称"，就是拿声称当事实
    if triggers and all(c.kind == "claim" for c in triggers):
        if not verdict.claim_fact_confusion:
            verdict.claim_fact_confusion = True
            verdict.overrides.append("claim_fact_confusion")

    # 3) 来源独立性：按独立性分组算，不按域名算
    supporting = [by_id[i] for i in verdict.supporting_clue_ids if i in by_id]
    groups = {c.independence_group for c in supporting if c.independence_group}
    if not supporting:
        computed = "unknown"
    elif len(groups) >= 2:
        computed = "multiple_independent"
    else:
        computed = "single"
    if computed != verdict.source_independence:
        verdict.source_independence = computed
        verdict.overrides.append("source_independence")

    # 4) 结论与置信必须自洽：falsified 不许还是 supported
    if verdict.falsification_result == "falsified" and verdict.verdict != "contradicted":
        verdict.verdict = "contradicted"
        verdict.overrides.append("verdict")

    # 5) 置信不得高于 verdict 允许的上限
    ceiling = verdict_to_confidence(verdict.verdict)
    clamped = clamp_confidence(verdict.revised_confidence, ceiling)
    if clamped != verdict.revised_confidence:
        verdict.revised_confidence = clamped
        verdict.overrides.append("revised_confidence")

    # 6) 单源 / 声称当事实 → 最高只能到 probable
    if verdict.claim_fact_confusion or verdict.source_independence == "single":
        tightened = clamp_confidence(verdict.revised_confidence, "probable")
        if tightened != verdict.revised_confidence:
            verdict.revised_confidence = tightened
            verdict.overrides.append("revised_confidence")

    # 7) 没有任何支撑线索却给出 confirmed，直接打回
    if not verdict.supporting_clue_ids and confidence_rank(
        verdict.revised_confidence
    ) < confidence_rank("speculative"):
        verdict.revised_confidence = "speculative"
        verdict.overrides.append("revised_confidence")

    return verdict


def _enforce_quota(verdicts: list[Verdict], ratio: float) -> QuotaResult:
    """证伪配额：至少 ratio 比例的候选假设先被证伪，才允许输出结论。

    达不到时，不隐藏结论，而是把所有结论压到 speculative 并显式告警。
    这比"悄悄给个 probable"诚实得多。
    """
    total = len(verdicts)
    if total == 0:
        return QuotaResult(required=0, actual=0, total=0, met=True, note="无候选假设")
    if total < 4:
        # 只有一两条假设时，"至少一半被证伪"在统计上没有意义：
        # 要么你被迫推翻唯一的结论，要么配额永远不达标。
        return QuotaResult(
            required=0,
            actual=sum(1 for v in verdicts if v.falsification_result == "falsified"),
            total=total,
            met=True,
            note=f"候选假设仅 {total} 条（<4），证伪配额不适用；结论强度按各自证据裁定。",
        )

    required = math.ceil(total * ratio)
    actual = sum(1 for v in verdicts if v.falsification_result == "falsified")
    met = actual >= required

    note = (
        f"已证伪 {actual}/{total} 条，达到配额 {required}。"
        if met
        else f"已证伪 {actual}/{total} 条，未达配额 {required}——本轮所有结论整体降级。"
    )
    if not met:
        for v in verdicts:
            if confidence_rank(v.revised_confidence) < confidence_rank("speculative"):
                v.revised_confidence = "speculative"
                v.overrides.append("falsification_quota")
    return QuotaResult(required=required, actual=actual, total=total, met=met, note=note)


def investigate(
    articles: list[Article],
    backend: Backend,
    max_hypotheses: int = 5,
    focus_entities: Optional[list[str]] = None,
    quota_ratio: float = 0.5,
    workers: int = 4,
    topic: Optional[Topic] = None,
) -> Investigation:
    warnings: list[str] = []

    clues = _extract_all(backend, articles, workers=workers)
    if not clues:
        warnings.append("没有抽到任何线索：检查材料是否为中文正文，或模型是否在改写原文。")

    base = build_evidence_base(clues)

    hypotheses = backend.generate_hypotheses(
        base, max_h=max_hypotheses, focus_entities=focus_entities
    )
    if not hypotheses:
        warnings.append("没有生成候选假设：证据图里可能没有可桥接的实体。")

    verdicts: list[Verdict] = []
    for h in hypotheses:
        pool = evidence_pool(base, h.trigger_clue_ids, hops=1)
        verdict = backend.adjudicate(h, base, pool)
        verdicts.append(_guard(h, verdict, base))

    quota = _enforce_quota(verdicts, quota_ratio)

    order = {"confirmed": 0, "probable": 1, "speculative": 2, "rejected": 3}
    verdicts.sort(key=lambda v: order.get(v.revised_confidence, 9))

    chain_report = build_chain_report(base, topic) if topic is not None else None

    return Investigation(
        articles=articles,
        base=base,
        hypotheses=hypotheses,
        verdicts=verdicts,
        quota=quota,
        backend_name=getattr(backend, "name", "unknown"),
        chain=chain_report,
        warnings=warnings,
    )
