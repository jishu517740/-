"""测试：验证的不是"代码能跑"，而是"纪律真的生效"。

如果哪天有人把证伪配额、锚点校验或来源独立性改成"看起来更好看"，
这些测试会失败——这正是它们存在的意义。
"""
from __future__ import annotations

import unittest
from pathlib import Path

from yanyun.backends.heuristic import HeuristicBackend, guess_entities
from yanyun.backends.llm import parse_json
from yanyun.fetch import load_articles
from yanyun.graph import build_evidence_base, detect_contradictions
from yanyun.pipeline import _enforce_quota, _guard, investigate
from yanyun.report import render_markdown
from yanyun.schema import Clue, Hypothesis, Verdict, stable_id
from yanyun.textutil import contains_anchor, find_iso_dates, find_quantities, registered_domain

SAMPLES = Path(__file__).resolve().parent.parent / "samples" / "articles.json"


def build_sample_base():
    backend = HeuristicBackend()
    articles = load_articles(SAMPLES)
    clues: list[Clue] = []
    for article in articles:
        clues += backend.extract_clues(
            article.text, article.url, article.title, default_year=2026
        )
    return build_evidence_base(clues)


class TestTextUtil(unittest.TestCase):
    def test_anchor_ignores_whitespace(self):
        self.assertTrue(contains_anchor("星港物流 项目\n启动", "星港物流项目启动"))
        self.assertFalse(contains_anchor("星港物流项目启动", "星港物流项目投产"))

    def test_stable_id_is_reproducible(self):
        self.assertEqual(stable_id("https://a.cn/x|句子", 1), stable_id("https://a.cn/x|句子", 1))
        self.assertNotEqual(stable_id("a", 0), stable_id("b", 0))

    def test_registered_domain(self):
        self.assertEqual(registered_domain("https://news.example.com.cn/a"), "example.com.cn")
        self.assertEqual(registered_domain("https://www.example.org/b"), "example.org")

    def test_date_normalization(self):
        self.assertEqual(find_iso_dates("2027年6月投产"), ["2027-06-01"])
        self.assertEqual(find_iso_dates("2026-11-13 发布"), ["2026-11-13"])

    def test_quantities(self):
        self.assertIn((8.2, "亿元"), find_quantities("总投资8.2亿元"))
        self.assertIn((30.0, "%"), find_quantities("减少30%人工"))


class TestEntityExtraction(unittest.TestCase):
    def test_does_not_glue_two_org_names(self):
        names = guess_entities("星港物流华南智能仓项目总投资8.2亿元")
        self.assertIn("星港物流", names)
        self.assertIn("华南智能仓", names)
        self.assertNotIn("星港物流华南智能仓", names)

    def test_person_single_surname(self):
        self.assertIn("李某", guess_entities("公司副总经理李某表示"))


class TestHardSignals(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = build_sample_base()

    def test_numeric_conflict_on_investment(self):
        numeric = [c for c in self.base.contradictions if c.kind == "numeric"]
        details = " ".join(c.detail for c in numeric)
        self.assertIn("6.5", details)
        self.assertIn("8.2", details)
        self.assertIn("某方声称", details)  # 6.5 是公司口径，必须标出来

    def test_temporal_conflict_on_production(self):
        temporal = [c for c in self.base.contradictions if c.kind == "temporal"]
        self.assertTrue(temporal)
        self.assertTrue(any("投产" in c.detail for c in temporal))
        self.assertEqual(temporal[0].action, "投产")

    def test_negation_against_record(self):
        negation = [c for c in self.base.contradictions if c.kind == "negation"]
        self.assertTrue(negation)
        self.assertTrue(any(c.entity == "星港物流" for c in negation))

    def test_syndication_detected(self):
        duplicates = [c for c in self.base.contradictions if c.kind == "duplicate"]
        self.assertTrue(duplicates)

    def test_syndicated_domains_share_group(self):
        groups = {
            clue.source_domain: clue.independence_group
            for clue in self.base.clues
            if clue.source_domain in ("example.cn", "example.net", "example.org")
        }
        self.assertEqual(groups["example.cn"], groups["example.net"])
        self.assertNotEqual(groups["example.org"], groups["example.cn"])


class TestProbeAndGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.backend = HeuristicBackend()
        cls.base = build_sample_base()
        cls.hypotheses = cls.backend.generate_hypotheses(cls.base, max_h=10)

    def test_value_hypothesis_is_falsified(self):
        target = next(
            h for h in self.hypotheses
            if h.probe and h.probe["kind"] == "value_agreement"
            and h.probe["entity"] == "星港物流"
        )
        verdict = self.backend.adjudicate(target, self.base, "")
        self.assertEqual(verdict.falsification_result, "falsified")
        self.assertEqual(verdict.verdict, "contradicted")
        self.assertEqual(verdict.revised_confidence, "rejected")
        self.assertTrue(verdict.contradicting_clue_ids)

    def test_negation_hypothesis_is_falsified_by_records(self):
        target = next(h for h in self.hypotheses if h.probe and h.probe["kind"] == "negation_record")
        verdict = self.backend.adjudicate(target, self.base, "")
        self.assertEqual(verdict.falsification_result, "falsified")

    def test_underreport_motive_never_confirmed(self):
        target = next(h for h in self.hypotheses if h.probe and h.probe["kind"] == "underreport")
        verdict = self.backend.adjudicate(target, self.base, "")
        self.assertNotEqual(verdict.revised_confidence, "confirmed")

    def test_guard_blocks_single_source_confirmed(self):
        clue = self.base.clues[0]
        hypothesis = Hypothesis(
            hypothesis="测试假设", type="motive",
            trigger_clue_ids=[clue.clue_id], falsifiable_prediction="应能观察到 X",
        )
        verdict = Verdict(
            hypothesis="测试假设", type="motive", falsifiable_prediction="应能观察到 X",
            verdict="supported", revised_confidence="confirmed",
            supporting_clue_ids=[clue.clue_id], source_independence="single",
            falsification_result="testable_but_unresolved",
        )
        guarded = _guard(hypothesis, verdict, self.base)
        self.assertEqual(guarded.revised_confidence, "probable")
        self.assertIn("revised_confidence", guarded.overrides)

    def test_guard_drops_invented_clue_ids(self):
        clue = self.base.clues[0]
        hypothesis = Hypothesis(
            hypothesis="测试假设", type="bridge",
            trigger_clue_ids=[clue.clue_id], falsifiable_prediction="应能观察到 X",
        )
        verdict = Verdict(
            hypothesis="测试假设", type="bridge", falsifiable_prediction="应能观察到 X",
            verdict="supported", revised_confidence="probable",
            supporting_clue_ids=["不存在的-id"], falsification_result="testable_but_unresolved",
        )
        guarded = _guard(hypothesis, verdict, self.base)
        self.assertEqual(guarded.supporting_clue_ids, [])
        self.assertEqual(guarded.revised_confidence, "speculative")

    def test_quota_downgrades_when_unmet(self):
        verdicts = [
            Verdict(
                hypothesis=f"h{i}", type="motive", falsifiable_prediction="p",
                verdict="supported", revised_confidence="confirmed",
                supporting_clue_ids=["x"], source_independence="multiple_independent",
                falsification_result="testable_but_unresolved",
            )
            for i in range(4)
        ]
        quota = _enforce_quota(verdicts, 0.5)
        self.assertFalse(quota.met)
        self.assertTrue(all(v.revised_confidence == "speculative" for v in verdicts))
        self.assertTrue(all("falsification_quota" in v.overrides for v in verdicts))


class TestEndToEnd(unittest.TestCase):
    def test_full_investigation(self):
        investigation = investigate(
            load_articles(SAMPLES), HeuristicBackend(), max_hypotheses=6
        )
        self.assertEqual(len(investigation.base.clues), 23)
        self.assertGreaterEqual(len(investigation.hypotheses), 5)
        self.assertTrue(investigation.quota.met)
        self.assertGreaterEqual(investigation.quota.actual, 3)

        report = render_markdown(investigation)
        for section in ("证伪配额", "硬信号", "假设与裁定", "信源独立性盘点", "线索台账"):
            self.assertIn(section, report)
        self.assertIn("已证伪", report)
        # 报告里不应出现"未经检验的肯定"
        self.assertNotIn("confirmed（多源独立 + 无矛盾）\n\n**陈述**：星港物流 一方的否认成立", report)


class TestJsonRepair(unittest.TestCase):
    def test_fenced_json(self):
        self.assertEqual(parse_json("```json\n[1, 2]\n```"), [1, 2])

    def test_trailing_comma(self):
        self.assertEqual(parse_json('{"a": 1,}'), {"a": 1})

    def test_text_around_object(self):
        self.assertEqual(parse_json('好的，结果如下：{"a": 2} 希望有帮助'), {"a": 2})


if __name__ == "__main__":
    unittest.main()
